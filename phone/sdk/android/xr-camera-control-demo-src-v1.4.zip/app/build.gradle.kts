plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

// 发布源码 zip 版本号，发布时手动 bump（产物名 xr-camera-control-demo-src-v<x>.zip）
// 与 SDK sdkVersion 保持一致（demo 展示 SDK 功能，跟随 SDK 升级）
val demoSrcVersion = "1.4"

android {
    namespace = "com.ssnwt.xr.demo"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.ssnwt.xr.demo"
        minSdk = 24
        targetSdk = 34
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // 依赖 SDK 编译产出的 AAR（非源码模块），模拟真实集成者。
    // 加载 libs/ 下所有 aar（文件名带版本号），避免硬编码版本号导致与 release/sdk 不匹配。
    implementation(fileTree("libs") { include("*.aar") })
    // AAR 不带传递依赖，宿主必须显式提供 SDK 运行期依赖
    implementation(libs.okhttp)
    implementation(libs.kotlinx.coroutines.android)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui.tooling.preview)
}

// ---------- 发布工程自维护任务 ----------

// 注：AAR / app 源码 / README 不再由本工程拉取，改由 SDK 工程 syncToDemo 推送（见
// sdk/xr-camera-control-android/xr-camera-control/build.gradle.kts）。本工程用已提交副本编译。

val releaseSdkDir = file("${rootDir}/../../release/sdk/android")

// demo APK → release/sdk/android
val copyApk by tasks.registering(Copy::class) {
    doFirst {
        // 删除旧版本 apk（含历史无版本号文件），避免残留多版本（*.apk 不误删 src zip）
        fileTree(releaseSdkDir) { include("xr-camera-control-demo*.apk") }.files.forEach { it.delete() }
    }
    from(layout.buildDirectory.dir("outputs/apk/release/app-release.apk"))
    into(releaseSdkDir)
    rename { "xr-camera-control-demo-v${demoSrcVersion}.apk" }
}

// demo 源码 zip → release/sdk/android（排除临时编译/本地环境文件）
val zipDemoSrc by tasks.registering(Zip::class) {
    archiveFileName.set("xr-camera-control-demo-src-v${demoSrcVersion}.zip")
    destinationDirectory.set(releaseSdkDir)
    from(rootDir) {
        exclude(
            "**/build/**", "**/.gradle/**", "**/.kotlin/**", "**/.idea/**",
            "**/.git/**", "**/*.iml", "**/captures/**", "**/local.properties",
            "**/*.hprof"
        )
    }
    // 注：.gitignore 不会进 zip —— Gradle 的 Zip 沿用 Ant defaultExcludes，对点开头 VCS 文件
    // (.gitignore/.gitattributes/.DS_Store) 强制排除且无公开 API 绕过。.gitignore 非构建必需，
    // 集成者用 IDE 初始化 git 时会自动生成，README 已注明。
}

afterEvaluate {
    tasks.named("assembleRelease") { finalizedBy(copyApk) }
    tasks.named("copyApk") { finalizedBy(zipDemoSrc) }
}
