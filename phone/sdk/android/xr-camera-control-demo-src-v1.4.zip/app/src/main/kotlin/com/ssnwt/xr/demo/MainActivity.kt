package com.ssnwt.xr.demo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.ssnwt.xrcamera.control.api.XrCameraClient
import com.ssnwt.xrcamera.control.api.listener.XrConnectionListener
import com.ssnwt.xrcamera.control.api.listener.XrDeviceListener
import com.ssnwt.xrcamera.control.api.listener.XrHandshankListener
import com.ssnwt.xrcamera.control.api.listener.XrRecordingListener
import com.ssnwt.xrcamera.control.api.listener.XrScanListener
import com.ssnwt.xrcamera.control.api.listener.XrTimeSyncListener
import com.ssnwt.xrcamera.control.api.model.CameraGroup
import com.ssnwt.xrcamera.control.api.model.ConnectionState
import com.ssnwt.xrcamera.control.api.model.DeviceInfo
import com.ssnwt.xrcamera.control.api.model.HandshankSide
import com.ssnwt.xrcamera.control.api.model.HandshankSideState
import com.ssnwt.xrcamera.control.api.model.ImuData
import com.ssnwt.xrcamera.control.api.model.TimeSyncState
import com.ssnwt.xrcamera.control.api.model.TimeSyncStatus
import com.ssnwt.xrcamera.control.api.model.WifiStatus
import com.ssnwt.xrcamera.control.api.model.WristDetail
import com.ssnwt.xrcamera.control.api.model.WristImuData
import com.ssnwt.xrcamera.control.api.model.WristPlaybackState
import com.ssnwt.xrcamera.control.api.model.XrDevice

// ---------- 多语言(中/英):Compose 状态 + SharedPreferences 持久化,切换即时生效 ----------
enum class AppLang { ZH, EN }

object AppLangState {
    private const val PREFS = "xr_demo_prefs"
    private const val KEY_LANG = "app_lang"

    var current by mutableStateOf(AppLang.ZH)
        private set

    fun init(ctx: Context) {
        current = if (ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_LANG, "zh") == "en") AppLang.EN else AppLang.ZH
    }

    fun toggle(ctx: Context) {
        current = if (current == AppLang.EN) AppLang.ZH else AppLang.EN
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LANG, if (current == AppLang.EN) "en" else "zh").apply()
    }
}

/** 字符串表:enum key 类型安全,带参数的用 %d/%s 按序 String.format */
private object L {
    enum class K {
        TITLE_CONFIG, WIFI_SSID, WIFI_PWD, BTN_SAVE, BTN_SCAN,
        STATUS_NOT_CONNECTED, STATUS_SCAN_DONE, STATUS_SCAN_ERROR,
        STATUS_BLE, STATUS_WIFI, STATUS_VR_IP, STATUS_ERROR, STATUS_DISCONNECTED,
        PREVIEW_PLAYING, WAITING_VR_IP, READY_TO_PREVIEW,
        CAMERA_GROUP, BTN_START_PREVIEW, BTN_STOP_PREVIEW,
        LABEL_BATTERY, LABEL_STORAGE, LABEL_VOLUME,
        LABEL_TIME_SYNC, NOT_SYNCED, LABEL_OFFSET,
        IMU_TITLE, IMU_ACCEL, IMU_GYRO, IMU_QUAT, IMU_TEMP, IMU_WAITING,
        PROJECTION_SWITCH, BTN_VOL_PLUS, BTN_VOL_MINUS, BTN_OFFSET_TEST,
        BTN_DELETE_DATA, BTN_RESTART, BTN_SHUTDOWN,
        LABEL_CHUNK_DUR, LABEL_UPLOAD_URL, BTN_SET, BTN_DISCONNECT,
        TOAST_CHUNK_SAVED, TOAST_RECORDING_STOPPED,
        // 新增接口
        HAND_TRACKING_SWITCH, USB_MODE_SWITCH,
        BTN_REC, BTN_STOP_REC,
        BTN_UPGRADE_CHECK, BTN_UPGRADE_START, BTN_USB_DEVICE_MODE,
        LABEL_MODEL, LABEL_VERSION,
        TOAST_RECORDING_STARTED, TOAST_RECORDING_ERROR,
        TOAST_UPGRADE_CHECK, TOAST_USB_CHANGED, TOAST_HAND_CHANGED,
        DIALOG_HAND_TITLE, DIALOG_HAND_MSG, DIALOG_USB_TITLE, DIALOG_USB_MSG,
        DIALOG_CONFIRM, DIALOG_OK, DIALOG_CANCEL,
        // 腕部手柄（ES202）
        HANDSHANK_LEFT, HANDSHANK_RIGHT, HANDSHANK_BONDED, HANDSHANK_CONNECTED,
        HANDSHANK_BLE, HANDSHANK_WIFI, HANDSHANK_BIND, HANDSHANK_UNBIND,
        HANDSHANK_UNBIND_CONFIRM,
        HANDSHANK_BIND_LEFT, HANDSHANK_BIND_RIGHT, HANDSHANK_BIND_START,
        HANDSHANK_BIND_PROMPT_WRIST, HANDSHANK_BIND_PROMPT_NORMAL,
        WRIST_CONNECTING, WRIST_OFFLINE,
        WRIST_SN, WRIST_SSID, WRIST_IP, WRIST_VERSION, WRIST_STORAGE, WRIST_BATTERY,
    }

    private val zh = mapOf(
        K.TITLE_CONFIG to "XR Camera Demo - 配网",
        K.WIFI_SSID to "WiFi SSID",
        K.WIFI_PWD to "WiFi 密码",
        K.BTN_SAVE to "保存",
        K.BTN_SCAN to "扫描",
        K.STATUS_NOT_CONNECTED to "未连接",
        K.STATUS_SCAN_DONE to "扫描完成，共 %d 个设备",
        K.STATUS_SCAN_ERROR to "扫描错误: %s",
        K.STATUS_BLE to "BLE: %s",
        K.STATUS_WIFI to "WiFi 状态: %s",
        K.STATUS_VR_IP to "VR IP: %s",
        K.STATUS_ERROR to "错误: %s",
        K.STATUS_DISCONNECTED to "已断开",
        K.PREVIEW_PLAYING to "预览中  %dx%d | %d FPS | %d KB/s",
        K.WAITING_VR_IP to "等待 VR IP...(配网中)",
        K.READY_TO_PREVIEW to "已就绪，点击「开始预览」启动视频",
        K.CAMERA_GROUP to "摄像头组: %s",
        K.BTN_START_PREVIEW to "开始预览",
        K.BTN_STOP_PREVIEW to "停止预览",
        K.LABEL_BATTERY to "电量",
        K.LABEL_STORAGE to "存储",
        K.LABEL_VOLUME to "音量",
        K.LABEL_TIME_SYNC to "时间同步",
        K.NOT_SYNCED to "未同步",
        K.LABEL_OFFSET to "偏移",
        K.IMU_TITLE to "IMU 数据:",
        K.IMU_ACCEL to "加速度",
        K.IMU_GYRO to "陀螺仪",
        K.IMU_QUAT to "四元数",
        K.IMU_TEMP to "温度",
        K.IMU_WAITING to "  等待数据...",
        K.PROJECTION_SWITCH to "投影",
        K.BTN_VOL_PLUS to "音量+",
        K.BTN_VOL_MINUS to "音量-",
        K.BTN_OFFSET_TEST to "偏移测试",
        K.BTN_DELETE_DATA to "删除数据",
        K.BTN_RESTART to "重启",
        K.BTN_SHUTDOWN to "关机",
        K.LABEL_CHUNK_DUR to "切片(分)",
        K.LABEL_UPLOAD_URL to "上传地址",
        K.BTN_SET to "设置",
        K.BTN_DISCONNECT to "断开",
        K.TOAST_CHUNK_SAVED to "分片保存: %s",
        K.TOAST_RECORDING_STOPPED to "录制停止: %s",
        // 新增接口
        K.HAND_TRACKING_SWITCH to "手势",
        K.USB_MODE_SWITCH to "USB",
        K.BTN_REC to "录制",
        K.BTN_STOP_REC to "停止",

        K.BTN_UPGRADE_CHECK to "OTA检测",
        K.BTN_UPGRADE_START to "OTA升级",
        K.BTN_USB_DEVICE_MODE to "USB模式",
        K.LABEL_MODEL to "型号",
        K.LABEL_VERSION to "版本",
        K.TOAST_RECORDING_STARTED to "录制开始: %s",
        K.TOAST_RECORDING_ERROR to "录制失败: %s",
        K.TOAST_UPGRADE_CHECK to "升级: %s",
        K.TOAST_USB_CHANGED to "USB已%s，重启后生效",
        K.TOAST_HAND_CHANGED to "手势追踪已%s，重启APP后生效",
        K.DIALOG_HAND_TITLE to "手势追踪",
        K.DIALOG_HAND_MSG to "修改手势追踪需重启VR APP，是否立即重启？",
        K.DIALOG_USB_TITLE to "USB 模式",
        K.DIALOG_USB_MSG to "修改USB模式需重启设备，是否立即重启？",
        K.DIALOG_CONFIRM to "确认重启",
        K.DIALOG_OK to "确认",
        K.DIALOG_CANCEL to "取消",
        K.HANDSHANK_LEFT to "左手柄",
        K.HANDSHANK_RIGHT to "右手柄",
        K.HANDSHANK_BONDED to "配对",
        K.HANDSHANK_CONNECTED to "连接",
        K.HANDSHANK_BLE to "BLE",
        K.HANDSHANK_WIFI to "WiFi",
        K.HANDSHANK_BIND to "绑定",
        K.HANDSHANK_UNBIND to "解绑",
        K.HANDSHANK_UNBIND_CONFIRM to "将同时解除左右手柄的绑定，是否继续？",
        K.HANDSHANK_BIND_LEFT to "左手绑定",
        K.HANDSHANK_BIND_RIGHT to "右手绑定",
        K.HANDSHANK_BIND_START to "开始绑定",
        K.HANDSHANK_BIND_PROMPT_WRIST to "按住功能键，连续点击电源键 5 次，进入绑定模式",
        K.HANDSHANK_BIND_PROMPT_NORMAL to "手柄上电后按住 HOME 键和 B/Y 键，进入绑定模式",
        K.WRIST_CONNECTING to "连接中…",
        K.WRIST_OFFLINE to "腕部设备不在线",
        K.WRIST_SN to "SN",
        K.WRIST_SSID to "WiFi",
        K.WRIST_IP to "IP",
        K.WRIST_VERSION to "版本",
        K.WRIST_STORAGE to "存储",
        K.WRIST_BATTERY to "电量",
    )
    private val en = mapOf(
        K.TITLE_CONFIG to "XR Camera Demo - Setup",
        K.WIFI_SSID to "WiFi SSID",
        K.WIFI_PWD to "WiFi Password",
        K.BTN_SAVE to "Save",
        K.BTN_SCAN to "Scan",
        K.STATUS_NOT_CONNECTED to "Not connected",
        K.STATUS_SCAN_DONE to "Scan finished, %d device(s) found",
        K.STATUS_SCAN_ERROR to "Scan error: %s",
        K.STATUS_BLE to "BLE: %s",
        K.STATUS_WIFI to "WiFi status: %s",
        K.STATUS_VR_IP to "VR IP: %s",
        K.STATUS_ERROR to "Error: %s",
        K.STATUS_DISCONNECTED to "Disconnected",
        K.PREVIEW_PLAYING to "Playing  %dx%d | %d FPS | %d KB/s",
        K.WAITING_VR_IP to "Waiting for VR IP...(configuring)",
        K.READY_TO_PREVIEW to "Ready, tap \"Start Preview\" to play",
        K.CAMERA_GROUP to "Camera: %s",
        K.BTN_START_PREVIEW to "Start Preview",
        K.BTN_STOP_PREVIEW to "Stop Preview",
        K.LABEL_BATTERY to "Battery",
        K.LABEL_STORAGE to "Storage",
        K.LABEL_VOLUME to "Volume",
        K.LABEL_TIME_SYNC to "Time sync",
        K.NOT_SYNCED to "Not synced",
        K.LABEL_OFFSET to "Offset",
        K.IMU_TITLE to "IMU Data:",
        K.IMU_ACCEL to "Accel",
        K.IMU_GYRO to "Gyro",
        K.IMU_QUAT to "Quat",
        K.IMU_TEMP to "Temp",
        K.IMU_WAITING to "  Waiting for data...",
        K.PROJECTION_SWITCH to "Proj",
        K.BTN_VOL_PLUS to "Vol+",
        K.BTN_VOL_MINUS to "Vol-",
        K.BTN_OFFSET_TEST to "Offset Test",
        K.BTN_DELETE_DATA to "Delete",
        K.BTN_RESTART to "Restart",
        K.BTN_SHUTDOWN to "Shutdown",
        K.LABEL_CHUNK_DUR to "Chunk(min)",
        K.LABEL_UPLOAD_URL to "Upload URL",
        K.BTN_SET to "Set",
        K.BTN_DISCONNECT to "Disconnect",
        K.TOAST_CHUNK_SAVED to "Chunk saved: %s",
        K.TOAST_RECORDING_STOPPED to "Recording stopped: %s",
        // New interfaces
        K.HAND_TRACKING_SWITCH to "Hand",
        K.USB_MODE_SWITCH to "USB",
        K.BTN_REC to "Rec",
        K.BTN_STOP_REC to "Stop",

        K.BTN_UPGRADE_CHECK to "OTA Check",
        K.BTN_UPGRADE_START to "OTA Upgrade",
        K.BTN_USB_DEVICE_MODE to "USB Mode",
        K.LABEL_MODEL to "Model",
        K.LABEL_VERSION to "Ver",
        K.TOAST_RECORDING_STARTED to "Rec started: %s",
        K.TOAST_RECORDING_ERROR to "Rec error: %s",
        K.TOAST_UPGRADE_CHECK to "Upgrade: %s",
        K.TOAST_USB_CHANGED to "USB %s, reboot to apply",
        K.TOAST_HAND_CHANGED to "Hand %s, restart APP to apply",
        K.DIALOG_HAND_TITLE to "Hand Tracking",
        K.DIALOG_HAND_MSG to "Restart VR APP to apply?",
        K.DIALOG_USB_TITLE to "USB Mode",
        K.DIALOG_USB_MSG to "Reboot device to apply?",
        K.DIALOG_CONFIRM to "Restart",
        K.DIALOG_OK to "OK",
        K.DIALOG_CANCEL to "Cancel",
        K.HANDSHANK_LEFT to "Left",
        K.HANDSHANK_RIGHT to "Right",
        K.HANDSHANK_BONDED to "Bonded",
        K.HANDSHANK_CONNECTED to "Connected",
        K.HANDSHANK_BLE to "BLE",
        K.HANDSHANK_WIFI to "WiFi",
        K.HANDSHANK_BIND to "Bind",
        K.HANDSHANK_UNBIND to "Unbind",
        K.HANDSHANK_UNBIND_CONFIRM to "This will unbind both controllers. Continue?",
        K.HANDSHANK_BIND_LEFT to "Pair Left",
        K.HANDSHANK_BIND_RIGHT to "Pair Right",
        K.HANDSHANK_BIND_START to "Start Pairing",
        K.HANDSHANK_BIND_PROMPT_WRIST to "Hold the function key and quickly press the power button 5 times to enter pairing mode",
        K.HANDSHANK_BIND_PROMPT_NORMAL to "Power on the controller, then hold the HOME and B/Y buttons to enter pairing mode",
        K.WRIST_CONNECTING to "Connecting...",
        K.WRIST_OFFLINE to "Wrist device offline",
        K.WRIST_SN to "SN",
        K.WRIST_SSID to "WiFi",
        K.WRIST_IP to "IP",
        K.WRIST_VERSION to "Version",
        K.WRIST_STORAGE to "Storage",
        K.WRIST_BATTERY to "Battery",
    )

    private val all = mapOf(AppLang.ZH to zh, AppLang.EN to en)
    operator fun get(lang: AppLang, k: K): String = all.getValue(lang).getValue(k)
}

/** 二次确认弹窗：标题 + 消息 + 确认/取消按钮。pending 为非 null 时显示，确认后回调 [onConfirm]。 */
@Composable
private fun ConfirmDialog(
    pending: Boolean?,
    onDismiss: () -> Unit,
    title: String,
    message: String,
    confirmText: String,
    onConfirm: (Boolean) -> Unit,
) {
    pending?.let { value ->
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { onConfirm(value); onDismiss() }) {
                    Text(confirmText)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(L[AppLangState.current, L.K.DIALOG_CANCEL])
                }
            },
        )
    }
}

/** 腕部手柄(ES202)状态卡：左右数据任一非 null 时显示；三按钮（左手绑定/右手绑定/解绑）由 showBindActions 控制
 *  （对齐 Flutter settings_drawer 手柄绑定入口条件：机型判定 isSXR1，非 wristSupported 能力位）。
 *  解绑仅全局入口：svrserver 仅支持 unbond(-1) 两柄同解（side 仅回显），按侧解绑会误导。
 *  showDetail=true（腕部手柄）时详情/IMU 跟在灯位电量后同块多排显示，非腕部仅单排灯位+电量。 */
@Composable
private fun WristHandshankCard(
    lang: AppLang,
    left: HandshankSideState?,
    right: HandshankSideState?,
    showWristLamps: Boolean,
    showBindActions: Boolean,
    showDetail: Boolean,
    detailLeft: WristDetail?,
    detailRight: WristDetail?,
    imuLeft: WristImuData?,
    imuRight: WristImuData?,
    onBond: (HandshankSide, Boolean) -> Unit, // (side, bind)；解绑时 side 仅回显，固定传 LEFT
) {
    if (left == null && right == null) return // 无数据整卡隐藏（E2 老固件自然隐藏）
    val t = { k: L.K -> L[lang, k] }
    Column(Modifier.fillMaxWidth()) {
        listOf(
            Triple(L.K.HANDSHANK_LEFT, left, detailLeft to imuLeft),
            Triple(L.K.HANDSHANK_RIGHT, right, detailRight to imuRight),
        ).forEach { (key, st, extra) ->
            if (st != null) {
                val (d, imu) = extra
                // 灯位按能力位降级（对齐 Flutter handshank_status_card full/full=false 两档逻辑）：
                // 腕部手柄四灯（配对/连接/BLE/WiFi），非腕部只显示 配对/连接 两灯
                Row(Modifier.fillMaxWidth()) {
                    Text("${t(key)}: ", style = MaterialTheme.typography.bodySmall)
                    // 内容列：第 1 排灯位+电量；腕部手柄追加详情/IMU 两排（长行小字号自然换行）
                    Column(Modifier.weight(1f)) {
                        Text(
                            "${t(L.K.HANDSHANK_BONDED)}=${if (st.bonded) "●" else "○"} " +
                                "${t(L.K.HANDSHANK_CONNECTED)}=${if (st.connected) "●" else "○"}" +
                                (if (showWristLamps)
                                    " ${t(L.K.HANDSHANK_BLE)}=${if (st.bleConnected) "●" else "○"} " +
                                    "${t(L.K.HANDSHANK_WIFI)}=${if (st.wifiConnected) "●" else "○"}"
                                else "") +
                                (st.battery?.let { "  ${t(L.K.WRIST_BATTERY)}=$it%" } ?: ""),
                            style = MaterialTheme.typography.bodySmall)
                        if (showDetail) {
                            // 无数据显示 "--"，明确表达接口在而数据链路无数据
                            Text(
                                "${t(L.K.WRIST_SN)}:${d?.sn ?: "--"}  " +
                                    "${t(L.K.WRIST_SSID)}:${d?.wifiSsid ?: "--"}  " +
                                    "${t(L.K.WRIST_IP)}:${d?.wifiIp ?: "--"}  " +
                                    "${t(L.K.WRIST_VERSION)}:${d?.version ?: "--"}  " +
                                    "${t(L.K.WRIST_STORAGE)}:${d?.storageTotalMb ?: "--"}/${d?.storageUsedMb ?: "--"}MB",
                                style = MaterialTheme.typography.bodySmall)
                            Text(
                                "${t(L.K.IMU_ACCEL)}:${imu?.ax?.let { "%.2f".format(it) } ?: "--"},${imu?.ay?.let { "%.2f".format(it) } ?: "--"},${imu?.az?.let { "%.2f".format(it) } ?: "--"}  " +
                                    "${t(L.K.IMU_GYRO)}:${imu?.gx?.let { "%.2f".format(it) } ?: "--"},${imu?.gy?.let { "%.2f".format(it) } ?: "--"},${imu?.gz?.let { "%.2f".format(it) } ?: "--"}",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        // 三按钮行：左/右绑定按侧发起（已绑定侧禁用），解绑为全局入口（任一侧已绑定才可用；
        // svrserver 仅支持 unbond(-1) 两柄同解，side 仅回显固定传 LEFT）。
        // 紧凑样式：32dp 高 + 零垂直 contentPadding（默认 48dp+8dp padding 视觉过松）
        if (showBindActions) {
            Row(Modifier.fillMaxWidth()) {
                TextButton(
                    onClick = { onBond(HandshankSide.LEFT, true) },
                    enabled = left?.bonded != true,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                ) {
                    Text(t(L.K.HANDSHANK_BIND_LEFT), fontSize = 12.sp, maxLines = 1)
                }
                TextButton(
                    onClick = { onBond(HandshankSide.RIGHT, true) },
                    enabled = right?.bonded != true,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                ) {
                    Text(t(L.K.HANDSHANK_BIND_RIGHT), fontSize = 12.sp, maxLines = 1)
                }
                TextButton(
                    onClick = { onBond(HandshankSide.LEFT, false) },
                    enabled = left?.bonded == true || right?.bonded == true,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                    modifier = Modifier.weight(1f).height(32.dp)
                ) {
                    Text(t(L.K.HANDSHANK_UNBIND), fontSize = 12.sp, color = Color.Red, maxLines = 1)
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    private val client by lazy { XrCameraClient(this, enableDebugLogging = true) }

    // 必须在 Activity 层注册（字段注册），不能在方法内注册后立即 launch
    private val permLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLangState.init(this)   // 读上次语言选择(默认中文)
        requestBlePermissions()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    DemoApp(client)
                }
            }
        }
    }

    private fun requestBlePermissions() {
        val needed = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            .toTypedArray()
        if (needed.isNotEmpty()) {
            permLauncher.launch(needed)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        client.release()
    }
}

@Composable
private fun DemoApp(client: XrCameraClient) {
    var screen by remember { mutableStateOf("config") }
    val conn by client.connectionState.collectAsState()
    LaunchedEffect(conn) {
        if (conn == ConnectionState.CONNECTED) {
            screen = "preview"
        } else if (conn == ConnectionState.DISCONNECTED && screen == "preview") {
            screen = "config"
        }
    }
    BackHandler(enabled = screen == "preview") { client.disconnect() }
    when (screen) {
        "config" -> ConfigScreen(client)
        else -> PreviewScreen(client)
    }
}

@Composable
private fun ConfigScreen(client: XrCameraClient) {
    val lang = AppLangState.current
    val t = { k: L.K -> L[lang, k] }
    val ctx = LocalContext.current
    val devices = remember { mutableStateListOf<XrDevice>() }
    val prefs = ctx.getSharedPreferences("xr_demo", Context.MODE_PRIVATE)
    var ssid by remember { mutableStateOf(prefs.getString("ssid", "") ?: "") }
    var password by remember { mutableStateOf(prefs.getString("password", "") ?: "") }
    // status 存 key+参数,显示时按当前语言格式化(切语言即时刷新,不再缓存旧语言文本)
    var statusKey by remember { mutableStateOf(L.K.STATUS_NOT_CONNECTED) }
    var statusArgs by remember { mutableStateOf<List<Any>>(emptyList()) }
    fun setStatus(k: L.K, args: List<Any> = emptyList()) { statusKey = k; statusArgs = args }

    DisposableEffect(Unit) {
        client.setScanListener(object : XrScanListener {
            override fun onDeviceFound(device: XrDevice) {
                // 显示所有发现的设备
                if (devices.none { it.mac == device.mac }) devices.add(device)
            }

            override fun onScanFinished(d: List<XrDevice>) {
                setStatus(L.K.STATUS_SCAN_DONE, listOf(d.size))
            }

            override fun onScanError(message: String) {
                setStatus(L.K.STATUS_SCAN_ERROR, listOf(message))
            }
        })
        client.setConnectionListener(object : XrConnectionListener {
            override fun onBleStateChanged(state: ConnectionState) {
                setStatus(L.K.STATUS_BLE, listOf(state))
            }

            override fun onWifiStatus(s: WifiStatus) {
                setStatus(L.K.STATUS_WIFI, listOf(s.name))
            }

            override fun onVrIpAddress(ip: String) {
                setStatus(L.K.STATUS_VR_IP, listOf(ip))
            }

            override fun onError(message: String) {
                setStatus(L.K.STATUS_ERROR, listOf(message))
            }

            override fun onDisconnected() {
                setStatus(L.K.STATUS_DISCONNECTED)
            }
        })
        onDispose { }
    }

    Column(Modifier.padding(16.dp).fillMaxSize()) {
        // 标题行:左标题,右上角语言切换(按钮文案为目标语言名)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(t(L.K.TITLE_CONFIG), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { AppLangState.toggle(ctx) }) {
                Text(if (lang == AppLang.ZH) "English" else "中文")
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            ssid, { ssid = it },
            label = { Text(t(L.K.WIFI_SSID)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            password, { password = it },
            label = { Text(t(L.K.WIFI_PWD)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Button({ prefs.edit().putString("ssid", ssid).putString("password", password).apply() }) {
            Text(t(L.K.BTN_SAVE))
        }
        Spacer(Modifier.height(8.dp))
        Button({
            client.stopScan()       // 停上一次扫描(如在跑),避免回调叠加
            devices.clear()
            client.startScan()
        }) { Text(t(L.K.BTN_SCAN)) }
        Spacer(Modifier.height(8.dp))
        val statusText = run {
            val fmt = L[lang, statusKey]
            if (statusArgs.isEmpty()) fmt else fmt.format(*statusArgs.toTypedArray())
        }
        Text(statusText, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(devices) { d ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            client.connect(d, ssid, password)
                        }
                        .padding(8.dp)
                ) {
                    Text(d.name, style = MaterialTheme.typography.bodyLarge)
                    Text("${d.serialNumber}  ${d.mac}", style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun PreviewScreen(client: XrCameraClient) {
    val lang = AppLangState.current
    val t = { k: L.K -> L[lang, k] }
    val stats by client.videoStats.collectAsState()
    val info by client.deviceInfo.collectAsState()
    val conn by client.connectionState.collectAsState()
    val handLeft by client.handshankLeft.collectAsState()
    val handRight by client.handshankRight.collectAsState()
    val wristPlayback by client.wristPlayback.collectAsState()
    // 腕部详情 + IMU（XrHandshankListener 回调填充；进 wrist 组时自动拉取）
    var wristDetailL by remember { mutableStateOf<WristDetail?>(null) }
    var wristDetailR by remember { mutableStateOf<WristDetail?>(null) }
    var wristImuL by remember { mutableStateOf<WristImuData?>(null) }
    var wristImuR by remember { mutableStateOf<WristImuData?>(null) }
    var wristSideForDialog by remember { mutableStateOf<HandshankSide?>(null) }
    var wristBindAction by remember { mutableStateOf(false) } // true=绑定 false=解绑
    // E2 设备以 SSC 开头，E6 以 SXR 开头
    val isE2 = info.deviceModel.startsWith("SSC")
    var imu by remember { mutableStateOf<ImuData?>(null) }
    var timeSync by remember { mutableStateOf<TimeSyncState?>(null) }
    var group by remember { mutableStateOf(CameraGroup.RGB) }
    var groupExpanded by remember { mutableStateOf(false) }
    var previewActive by remember { mutableStateOf(false) }
    // 新增接口状态
    var recordingActive by remember { mutableStateOf(info.recording) }
    var handDialogPending by remember { mutableStateOf<Boolean?>(null) }
    var usbDialogPending by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(info.recording) { recordingActive = info.recording }
    val context = LocalContext.current

    DisposableEffect(Unit) {
        client.setDeviceListener(object : XrDeviceListener {
            override fun onDeviceInfo(i: DeviceInfo) {}  // StateFlow 自动更新,无需手动刷新
            override fun onImuData(imuData: ImuData) { imu = imuData }
            override fun onUsbModeChanged(enabled: Boolean) {
                Toast.makeText(context,
                    L[AppLangState.current, L.K.TOAST_USB_CHANGED].format(if (enabled) "开启" else "关闭"),
                    Toast.LENGTH_LONG).show()
            }
            override fun onHandTrackingRestartRequired(enabled: Boolean) {
                Toast.makeText(context,
                    L[AppLangState.current, L.K.TOAST_HAND_CHANGED].format(if (enabled) "开启" else "关闭"),
                    Toast.LENGTH_LONG).show()
            }
            override fun onUpgradeCheckResult(result: String) {
                Toast.makeText(context,
                    L[AppLangState.current, L.K.TOAST_UPGRADE_CHECK].format(result),
                    Toast.LENGTH_LONG).show()
            }
        })
        client.setRecordingListener(object : XrRecordingListener {
            override fun onChunkSaved(path: String) {
                Toast.makeText(
                    context,
                    L[AppLangState.current, L.K.TOAST_CHUNK_SAVED].format(path),
                    Toast.LENGTH_LONG
                ).show()
            }
            override fun onRecordingStopped(reason: String) {
                recordingActive = false
                Toast.makeText(
                    context,
                    L[AppLangState.current, L.K.TOAST_RECORDING_STOPPED].format(reason),
                    Toast.LENGTH_LONG
                ).show()
            }
            override fun onRecordingStarted(savePath: String, recordStartMs: Long) {
                recordingActive = true
                Toast.makeText(
                    context,
                    L[AppLangState.current, L.K.TOAST_RECORDING_STARTED].format(savePath),
                    Toast.LENGTH_LONG
                ).show()
            }
            override fun onRecordingError(error: String) {
                Toast.makeText(
                    context,
                    L[AppLangState.current, L.K.TOAST_RECORDING_ERROR].format(error),
                    Toast.LENGTH_LONG
                ).show()
            }
        })
        client.setTimeSyncListener(object : XrTimeSyncListener {
            override fun onTimeSyncState(state: TimeSyncState) { timeSync = state }
        })
        onDispose {
            // 离开预览页仅清理 listener，不停止预览。
            // 停止预览统一由"停止预览"按钮、BackHandler disconnect、或 surface 销毁触发。
            client.setTimeSyncListener(null)
        }
    }

    // 手柄/腕部回调注册（离开本屏注销）
    DisposableEffect(Unit) {
        client.setHandshankListener(object : XrHandshankListener {
            override fun onHandshankStatus(side: HandshankSide, state: HandshankSideState) {}
            override fun onHandshankBondError(side: HandshankSide, error: String) {
                // demo 简化：绑定失败用既有错误提示位（状态卡灯位随 StateFlow 自行恢复）
            }
            override fun onWristDetail(side: HandshankSide, detail: WristDetail?) {
                if (side == HandshankSide.LEFT) wristDetailL = detail
                else wristDetailR = detail
            }
            override fun onWristImu(side: HandshankSide, imu: WristImuData) {
                if (side == HandshankSide.LEFT) wristImuL = imu
                else wristImuR = imu
            }
        })
        onDispose { client.setHandshankListener(null) }
    }

    // 腕部详情/IMU 拉取按能力位门控（wristSupported 由 get_device_info 应答就绪，连接瞬间可能为 null，
    // 故监听 conn + wristSupported，能力位就绪后自动触发）：CONNECTED 且腕部手柄时拉双侧详情 + 开 IMU 推送，
    // 否则（断开或非腕部）关 IMU 推送
    LaunchedEffect(conn, info.wristSupported) {
        if (conn == ConnectionState.CONNECTED && info.wristSupported == true) {
            client.getWristDetail(HandshankSide.LEFT)
            client.getWristDetail(HandshankSide.RIGHT)
            client.setWristImuEnabled(true)
        } else if (conn == ConnectionState.CONNECTED) {
            // 仅连接态下发关推送：断开时 gatt 为 null，命令会滞留写队列、下次连接被冲刷（脏写）
            client.setWristImuEnabled(false)
        }
    }
    // 断连：组回落 RGB（设计 §5/§7——SDK 重置触达不了 demo 本地 state，此处闭环）
    LaunchedEffect(conn) {
        if (conn != ConnectionState.CONNECTED && group == CameraGroup.WRIST) group = CameraGroup.RGB
    }

    // Surface 由 SurfaceView 生命周期持有;预览由下方「开始预览」按钮显式触发(失败可重试)
    var previewSurface by remember { mutableStateOf<Surface?>(null) }
    var previewSurface1 by remember { mutableStateOf<Surface?>(null) }  // E2 右目
    // wrist 双腕 Surface（surfaceCreated/Destroyed 成对维护，供另一侧回调读取当前值）
    val wristLeftSurfaceState = remember { mutableStateOf<Surface?>(null) }
    val wristRightSurfaceState = remember { mutableStateOf<Surface?>(null) }
    val vrIp = info.vrIp
    val playing = stats.fps > 0
    val canStart = if (isE2) previewSurface != null && previewSurface1 != null && !vrIp.isNullOrEmpty()
                   else previewSurface != null && !vrIp.isNullOrEmpty()

    Column(Modifier.padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState())) {
        // 0. 顶栏:型号+版本 | 断开(右对齐)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                buildString {
                    if (info.deviceModel.isNotEmpty()) append("${t(L.K.LABEL_MODEL)}:${info.deviceModel}")
                    if (info.vrVersion.isNotEmpty()) append("  ${t(L.K.LABEL_VERSION)}:${info.vrVersion}")
                },
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { client.disconnect() }) { Text(t(L.K.BTN_DISCONNECT)) }
        }
        Spacer(Modifier.height(4.dp))
        // 1. 视频预览
        if (group == CameraGroup.WRIST) {
            // wrist 双腕布局：左右 SurfaceView 各半 + 中间分隔线（样式参考 E2 双流分支）
            Row(Modifier.fillMaxWidth().aspectRatio(2.67f).background(Color.Black)) {
                listOf(true, false).forEach { left ->
                    if (!left) Box(Modifier.fillMaxHeight().width(1.dp).background(Color.DarkGray))
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        AndroidView(
                            factory = { ctx ->
                                SurfaceView(ctx).also { sv ->
                                    sv.holder.addCallback(object : SurfaceHolder.Callback {
                                        override fun surfaceCreated(h: SurfaceHolder) {
                                            val s = h.surface
                                            if (left) {
                                                wristLeftSurfaceState.value = s
                                                client.setWristSurfaces(s, wristRightSurfaceState.value)
                                            } else {
                                                wristRightSurfaceState.value = s
                                                client.setWristSurfaces(wristLeftSurfaceState.value, s)
                                            }
                                        }
                                        override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
                                        override fun surfaceDestroyed(h: SurfaceHolder) {
                                            // 只清该侧 Surface，不触碰 stopPreview（设计 §6.1 守卫）
                                            if (left) {
                                                wristLeftSurfaceState.value = null
                                                client.setWristSurfaces(null, wristRightSurfaceState.value)
                                            } else {
                                                wristRightSurfaceState.value = null
                                                client.setWristSurfaces(wristLeftSurfaceState.value, null)
                                            }
                                        }
                                    })
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        val st = if (left) wristPlayback.left else wristPlayback.right
                        if (st != WristPlaybackState.PLAYING) {
                            Text(
                                if (st == WristPlaybackState.CONNECTING)
                                    t(L.K.WRIST_CONNECTING) else t(L.K.WRIST_OFFLINE),
                                color = Color.White, modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }
            }
        } else if (isE2) {
            // E2 双流：左目 + 右目并排，中间分隔线
            Row(Modifier.fillMaxWidth().aspectRatio(2.67f).background(Color.Black)) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).also { sv ->
                            sv.holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(h: SurfaceHolder) { previewSurface = h.surface }
                                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
                                override fun surfaceDestroyed(h: SurfaceHolder) {
                                    previewSurface = null
                                    // E2 双流：只有两个 Surface 都销毁时才停止预览
                                    if (previewActive && previewSurface1 == null) {
                                        client.stopPreview(); previewActive = false
                                    }
                                }
                            })
                        }
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                Box(Modifier.fillMaxHeight().width(1.dp).background(Color.DarkGray))
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).also { sv ->
                            sv.holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(h: SurfaceHolder) { previewSurface1 = h.surface }
                                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
                                override fun surfaceDestroyed(h: SurfaceHolder) {
                                    previewSurface1 = null
                                    // E2 双流：只有两个 Surface 都销毁时才停止预览
                                    if (previewActive && previewSurface == null) {
                                        client.stopPreview(); previewActive = false
                                    }
                                }
                            })
                        }
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        } else {
            // E6 单流：单个 SurfaceView
            AndroidView(
                factory = { ctx ->
                    SurfaceView(ctx).also { sv ->
                        sv.holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(h: SurfaceHolder) {
                                previewSurface = h.surface
                                // 切离 wrist 后主 SurfaceView 重建：新 Surface 重投递主流，
                                // 修正 handleCmdOk 复用旧 Surface 的黑屏（设计 §6.1）
                                if (previewActive && group != CameraGroup.WRIST) {
                                    client.updateVideoSurface(h.surface)
                                }
                            }
                            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
                            override fun surfaceDestroyed(h: SurfaceHolder) {
                                previewSurface = null
                                // wrist 切换布局销毁主视图时不得 stopPreview（会掐断腕部流）；
                                // 用户点选 wrist 后 group 已先置 WRIST（设计 §6.1 守卫）
                                if (previewActive && group != CameraGroup.WRIST) {
                                    client.stopPreview(); previewActive = false
                                }
                            }
                        })
                    }
                },
                modifier = Modifier.fillMaxWidth().aspectRatio(2.67f).background(Color.Black)
            )
        }
        Spacer(Modifier.height(8.dp))
        // 2. 预览状态
        Text(
            when {
                playing -> L[lang, L.K.PREVIEW_PLAYING].format(
                    stats.width, stats.height, stats.fps, stats.byteRateKBps.toInt())
                vrIp.isNullOrEmpty() -> t(L.K.WAITING_VR_IP)
                else -> t(L.K.READY_TO_PREVIEW)
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (playing) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.height(8.dp))
        // 3. 摄像头组(E6) | 预览 | 录制(同一排,独立)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (!isE2) {
                Box(Modifier.weight(1f)) {
                    Button(onClick = { groupExpanded = !groupExpanded }, modifier = Modifier.fillMaxWidth()) {
                        Text(group.value, maxLines = 1, fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                        // wrist 项仅能力明确支持时显示（null/false 隐藏，防未知设备误切发脏命令）
                        CameraGroup.values().filter {
                            it != CameraGroup.WRIST || info.wristSupported == true
                        }.forEach { g ->
                            DropdownMenuItem(text = { Text(g.value) }, onClick = {
                                group = g; client.switchGroup(g); groupExpanded = false
                            })
                        }
                    }
                }
                Spacer(Modifier.width(2.dp))
            }
            Button(
                onClick = {
                    if (playing) { client.stopPreview(); previewActive = false }
                    else {
                        val s = previewSurface
                        if (s != null) {
                            previewActive = true
                            client.startPreview(group, s, previewSurface1)
                        }
                    }
                },
                enabled = playing || canStart,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    if (playing) t(L.K.BTN_STOP_PREVIEW) else t(L.K.BTN_START_PREVIEW),
                    maxLines = 1, fontSize = 12.sp
                )
            }
            Spacer(Modifier.width(2.dp))
            Button(
                onClick = {
                    if (recordingActive) client.stopRecording() else client.startRecording()
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    if (recordingActive) t(L.K.BTN_STOP_REC) else t(L.K.BTN_REC),
                    maxLines = 1, fontSize = 12.sp,
                    color = if (recordingActive) Color.Red else Color.Unspecified
                )
            }
        }
        // 3.5 腕部手柄(ES202)状态卡（左右数据任一非 null 才显示）
        // 绑定/解绑按钮对齐 Flutter settings_drawer.dart:437 入口条件（机型 isSXR1，非 wristSupported 能力位；
        // 真机 303D/E2 GATT 为 0 时能力位恒 false 会导致按钮不可见）
        // 详情/IMU 排仅腕部手柄（wristSupported==true）显示，跟在灯位电量后同块多排
        WristHandshankCard(lang, handLeft, handRight,
            showWristLamps = info.wristSupported == true,
            showBindActions = info.deviceModel == "SXR_1",
            showDetail = info.wristSupported == true,
            detailLeft = wristDetailL, detailRight = wristDetailR,
            imuLeft = wristImuL, imuRight = wristImuR) { side, bind ->
            wristSideForDialog = side; wristBindAction = bind
        }
        Spacer(Modifier.height(8.dp))
        // 4. 设备状态
        val ts = timeSync
        Text(
            buildString {
                append("WiFi: ${info.wifiSsid} | VR IP: ${info.vrIp ?: "--"}")
                append("\n${t(L.K.LABEL_BATTERY)}: ${if (info.batteryPercent >= 0) "${info.batteryPercent}%" else "--"} | SN: ${info.serialNumber} | " +
                    "${t(L.K.LABEL_STORAGE)}: ${info.storageUsedMb}/${info.storageTotalMb}MB")
                if (!isE2) append(" | ${t(L.K.LABEL_VOLUME)}: ${info.volume}/${info.maxVolume}")
                info.datasetDir?.let { append("\nDataset: $it") }
                if (!isE2) {
                    append(" | ${t(L.K.LABEL_TIME_SYNC)}: ${ts?.status?.label(lang) ?: t(L.K.NOT_SYNCED)}")
                    // setClock 方案：VR 实时校正系统时钟，偏移即当前测量 offset（无独立校正后残差展示）
                    val off = ts?.offsetMs
                    if (off != null) {
                        append(" | ${t(L.K.LABEL_OFFSET)}: ${"%.3fms".format(off)}")
                    }
                }
            },
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        // 5. IMU
        val imuData = imu
        Text(
            buildString {
                appendLine(t(L.K.IMU_TITLE))
                if (imuData != null) {
                    appendLine("  ${t(L.K.IMU_ACCEL)} ax=${imuData.accelX ?: "--"} ay=${imuData.accelY ?: "--"} az=${imuData.accelZ ?: "--"}")
                    appendLine("  ${t(L.K.IMU_GYRO)} gx=${imuData.gyroX ?: "--"} gy=${imuData.gyroY ?: "--"} gz=${imuData.gyroZ ?: "--"}")
                    // E2 不支持四元数和温度（对齐 Flutter isSSC303D 的隐藏逻辑）
                    if (!isE2) {
                        appendLine("  ${t(L.K.IMU_QUAT)} x=${imuData.quatX ?: "--"} y=${imuData.quatY ?: "--"} z=${imuData.quatZ ?: "--"} w=${imuData.quatW ?: "--"}")
                        append("  ${t(L.K.IMU_TEMP)}=${imuData.temperature ?: "--"}")
                    }
                } else append(t(L.K.IMU_WAITING))
            },
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        // 6. 手势 | 投影 | USB 开关(E6 专属)
        if (!isE2) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(t(L.K.HAND_TRACKING_SWITCH), fontSize = 12.sp)
                Switch(checked = info.handEnabled,
                    onCheckedChange = { v -> handDialogPending = v },
                    modifier = Modifier.height(32.dp))
                Spacer(Modifier.width(4.dp))
                Text(t(L.K.PROJECTION_SWITCH), fontSize = 12.sp)
                Switch(checked = info.projectEnabled,
                    onCheckedChange = { client.setProjectionEnabled(it) },
                    modifier = Modifier.height(32.dp))
                Spacer(Modifier.width(4.dp))
                Text(t(L.K.USB_MODE_SWITCH), fontSize = 12.sp)
                Switch(checked = info.usbEnabled,
                    onCheckedChange = { v -> usbDialogPending = v },
                    modifier = Modifier.height(32.dp))
            }
            Spacer(Modifier.height(8.dp))
        }
        // 7. 音量+/音量-/偏移测试(E6 专属)
        if (!isE2) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Button({ client.increaseVolume() }, modifier = Modifier.weight(1f)) {
                    Text(t(L.K.BTN_VOL_PLUS), maxLines = 1, fontSize = 12.sp)
                }
                Spacer(Modifier.width(4.dp))
                Button({ client.decreaseVolume() }, modifier = Modifier.weight(1f)) {
                    Text(t(L.K.BTN_VOL_MINUS), maxLines = 1, fontSize = 12.sp)
                }
                Spacer(Modifier.width(4.dp))
                Button(
                    { client.offsetTest() },
                    modifier = Modifier.weight(1f),
                    enabled = ts?.serialAvailable == true,  // 仅 PC 时间同步服务可达时可测
                ) {
                    Text(t(L.K.BTN_OFFSET_TEST), maxLines = 1, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        // 8. 删除/重启/关机
        Row(Modifier.fillMaxWidth()) {
            Button({ client.deleteData() }, modifier = Modifier.weight(1f)) {
                Text(t(L.K.BTN_DELETE_DATA), maxLines = 1, fontSize = 12.sp)
            }
            Spacer(Modifier.width(4.dp))
            Button({ client.reboot(); client.disconnect() }, modifier = Modifier.weight(1f)) {
                Text(t(L.K.BTN_RESTART), maxLines = 1, fontSize = 12.sp)
            }
            Spacer(Modifier.width(4.dp))
            Button({ client.shutdown(); client.disconnect() }, modifier = Modifier.weight(1f)) {
                Text(t(L.K.BTN_SHUTDOWN), maxLines = 1, fontSize = 12.sp)
            }
        }
        // 9-10. 录制配置(E6 专属)
        if (!isE2) {
            val prefs = remember { context.getSharedPreferences("xr_demo", Context.MODE_PRIVATE) }
            // 9. 切片时长
            Spacer(Modifier.height(8.dp))
            var chunkDur by remember { mutableStateOf(prefs.getString("chunk_dur", info.chunkDurationMin.toString()) ?: "30") }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(chunkDur, { chunkDur = it },
                    label = { Text(t(L.K.LABEL_CHUNK_DUR)) }, singleLine = true,
                    modifier = Modifier.weight(1f))
                Spacer(Modifier.width(4.dp))
                Button({
                    val v = chunkDur.toIntOrNull()
                    if (v != null) { prefs.edit().putString("chunk_dur", chunkDur).apply(); client.setChunkDuration(v) }
                }) { Text(t(L.K.BTN_SET)) }
            }
            // 10. 上传地址
            Spacer(Modifier.height(8.dp))
            var uploadUrl by remember { mutableStateOf(prefs.getString("upload_url", info.uploadUrl) ?: "") }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(uploadUrl, { uploadUrl = it },
                    label = { Text(t(L.K.LABEL_UPLOAD_URL)) }, singleLine = true,
                    modifier = Modifier.weight(1f))
                Spacer(Modifier.width(4.dp))
                Button({
                    val url = uploadUrl.trim()
                    if (url.isNotEmpty()) { prefs.edit().putString("upload_url", url).apply(); client.setUploadUrl(url) }
                }) { Text(t(L.K.BTN_SET)) }
            }
        }
        // 11. OTA 检测/升级/USB模式(E2 专属)
        if (isE2) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Button({ client.checkUpgrade() }, modifier = Modifier.weight(1f)) {
                    Text(t(L.K.BTN_UPGRADE_CHECK), maxLines = 1, fontSize = 11.sp)
                }
                Spacer(Modifier.width(4.dp))
                Button({ client.startUpgrade() }, modifier = Modifier.weight(1f)) {
                    Text(t(L.K.BTN_UPGRADE_START), maxLines = 1, fontSize = 11.sp)
                }
                Spacer(Modifier.width(4.dp))
                Button({ client.switchUsbDeviceMode() }, modifier = Modifier.weight(1f)) {
                    Text(t(L.K.BTN_USB_DEVICE_MODE), maxLines = 1, fontSize = 11.sp)
                }
            }
        }
    }

    // ---- 二次确认弹窗 ----
    ConfirmDialog(
        pending = handDialogPending,
        onDismiss = { handDialogPending = null },
        title = t(L.K.DIALOG_HAND_TITLE),
        message = t(L.K.DIALOG_HAND_MSG),
        confirmText = t(L.K.DIALOG_CONFIRM),
        onConfirm = { client.setHandEnabled(it); client.restartApp(); client.disconnect() }
    )
    ConfirmDialog(
        pending = usbDialogPending,
        onDismiss = { usbDialogPending = null },
        title = t(L.K.DIALOG_USB_TITLE),
        message = t(L.K.DIALOG_USB_MSG),
        confirmText = t(L.K.DIALOG_CONFIRM),
        onConfirm = { client.setUsbMode(it); client.reboot(); client.disconnect() }
    )
    ConfirmDialog(
        pending = wristSideForDialog?.let { wristBindAction },
        onDismiss = { wristSideForDialog = null },
        title = if (wristBindAction) {
            t(if (wristSideForDialog == HandshankSide.RIGHT) L.K.HANDSHANK_BIND_RIGHT else L.K.HANDSHANK_BIND_LEFT)
        } else t(L.K.HANDSHANK_UNBIND),
        // 绑定时按手柄型号给进入绑定模式的操作指引（ES202=功能键+电源键5次，普通=HOME+B/Y）。
        // 不能用 wristSupported——那是 E2 腕部相机能力位，无 E2 的 CS02 设备手柄仍是 ES202
        // （2026-08-29 误判根因）；es202Handshank 为 null（旧固件未下发）回退 wristSupported，
        // 与 Flutter handshank_bind_dialog 回退语义一致。
        message = if (wristBindAction) {
            t(if (info.es202Handshank ?: (info.wristSupported == true)) L.K.HANDSHANK_BIND_PROMPT_WRIST else L.K.HANDSHANK_BIND_PROMPT_NORMAL)
        } else t(L.K.HANDSHANK_UNBIND_CONFIRM),
        confirmText = t(if (wristBindAction) L.K.HANDSHANK_BIND_START else L.K.DIALOG_OK),
        onConfirm = { bind ->
            wristSideForDialog?.let { side ->
                if (bind) client.bondHandshank(side) else client.unbondHandshank(side)
            }
        }
    )
}

// 时间同步状态枚举 → 精简展示(随当前语言)
private fun TimeSyncStatus.label(lang: AppLang): String {
    val en = lang == AppLang.EN
    return when (this) {
        TimeSyncStatus.COLLECTING -> if (en) "Syncing" else "同步中"
        TimeSyncStatus.CALIBRATED -> if (en) "Calibrated" else "已校准"
        TimeSyncStatus.STABLE -> if (en) "Synced" else "已同步"
        TimeSyncStatus.WARMING -> if (en) "Warming" else "预热中"
        TimeSyncStatus.NO_DATA -> if (en) "Not synced" else "未同步"
        TimeSyncStatus.DISCONNECTED -> if (en) "Disconnected" else "已断开"
        TimeSyncStatus.ERROR -> if (en) "Error" else "错误"
    }
}
