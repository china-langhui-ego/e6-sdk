//
//  Ego_ViewTests.swift
//  Ego ViewTests
//
//  Created by skyworth on 2026/6/15.
//

import Testing
@testable import Ego_View

struct Ego_ViewTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
