import Testing
import SwiftUI
@testable import Ego_View

/// 共享 UserDefaults.standard 的同一 key，必须串行执行（Swift Testing 默认并行，
/// 并发 setMode 会让持久化断言读到其他用例写入的值，偶发失败）。
@Suite(.serialized)
struct ThemeManagerTests {

    @Test func preferredColorScheme_system_isNil() {
        let m = ThemeManager()
        m.setMode(.system)
        #expect(m.preferredColorScheme() == nil)
    }

    @Test func preferredColorScheme_light_isLight() {
        let m = ThemeManager()
        m.setMode(.light)
        #expect(m.preferredColorScheme() == .light)
    }

    @Test func preferredColorScheme_dark_isDark() {
        let m = ThemeManager()
        m.setMode(.dark)
        #expect(m.preferredColorScheme() == .dark)
    }

    @Test func theme_forDarkScheme_isDarkTheme() {
        let m = ThemeManager()
        #expect(m.theme(for: .dark) == AppTheme.dark)
    }

    @Test func theme_forLightScheme_isLightTheme() {
        let m = ThemeManager()
        #expect(m.theme(for: .light) == AppTheme.light)
    }

    @Test func setMode_persists_rawValue() {
        let m = ThemeManager()
        m.setMode(.dark)
        let raw = UserDefaults.standard.string(forKey: "ego.appearanceMode")
        #expect(raw == "dark")
    }
}
