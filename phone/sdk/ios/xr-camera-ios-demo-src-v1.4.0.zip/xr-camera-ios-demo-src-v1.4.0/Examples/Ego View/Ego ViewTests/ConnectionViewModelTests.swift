import Testing
import Foundation
import XRCamera
@testable import Ego_View

struct ConnectionViewModelTests {

    @Test func connectionChanged_scanning_sets_isScanning() {
        let vm = ConnectionViewModel()
        vm.handle(.connectionChanged(.scanning))
        #expect(vm.connectionState == .scanning)
        #expect(vm.isScanning == true)
    }

    @Test func connected_uses_selected_device_name() {
        let vm = ConnectionViewModel()
        vm.selectedDevice = XrDevice(id: UUID(), name: "SXR_1", serialNumber: "SN123", rssi: -60)
        vm.handle(.connectionChanged(.connected))
        #expect(vm.isConnected == true)
        #expect(vm.connectedDeviceName == "SXR_1")
    }

    @Test func wifiStatus_updates_value() {
        let vm = ConnectionViewModel()
        vm.handle(.wifiStatus(.serversStarted))
        #expect(vm.wifiStatus == .serversStarted)
    }

    @Test func vrIpAddress_updates_value() {
        let vm = ConnectionViewModel()
        vm.handle(.vrIpAddress("192.168.1.10"))
        #expect(vm.vrIp == "192.168.1.10")
    }

    @Test func wsConnected_follows_firstFrame_and_stop() {
        let vm = ConnectionViewModel()
        vm.handle(.firstFrameDecoded)
        #expect(vm.wsConnected == true)
        vm.handle(.playingChanged(false))
        #expect(vm.wsConnected == false)
    }

    @Test func timeSync_updates_state() {
        let vm = ConnectionViewModel()
        vm.handle(.timeSync(TimeSyncState(status: .collecting, durationMs: 1000,
                                          totalMs: 120_000, onlineSync: true)))
        #expect(vm.timeSyncState.status == .collecting)
        #expect(vm.timeSyncState.remainingSec == 119)
    }

    @Test func deviceInfo_merges_incrementally() {
        let vm = ConnectionViewModel()
        var a = DeviceInfo(); a.battery = 80
        vm.handle(.deviceInfo(a))
        var b = DeviceInfo(); b.sn = "SN999"
        vm.handle(.deviceInfo(b))
        #expect(vm.deviceInfo.battery == 80)
        #expect(vm.deviceInfo.sn == "SN999")
    }

    @Test func isE2_requires_ssc_device_model() {
        let vm = ConnectionViewModel()
        #expect(vm.isE2 == false) // deviceModel 未知时按非 E2 处理（隐藏升级入口）
        var info = DeviceInfo(); info.deviceModel = "SSC303D"
        vm.handle(.deviceInfo(info))
        #expect(vm.isE2 == true)
        var other = DeviceInfo(); other.deviceModel = "SXR109"
        vm.handle(.deviceInfo(other))
        #expect(vm.isE2 == false)
    }

    @Test func disconnected_clears_runtime_state() {
        let vm = ConnectionViewModel()
        vm.selectedDevice = XrDevice(id: UUID(), name: "SXR_1")
        vm.handle(.connectionChanged(.connected))
        vm.handle(.vrIpAddress("1.2.3.4"))
        vm.handle(.disconnected)
        #expect(vm.vrIp == nil)
        #expect(vm.connectedDeviceName == nil)
    }

    @Test func error_bluetoothUnavailable_is_readable() {
        let vm = ConnectionViewModel()
        vm.handle(.error(.bluetoothUnavailable))
        #expect(vm.lastError?.contains("蓝牙") == true)
    }

    @Test func error_wifiFailed_is_readable() {
        let vm = ConnectionViewModel()
        vm.handle(.error(.wifiFailed))
        #expect(vm.lastError?.contains("WiFi") == true)
    }

    @Test func imu_updates_from_event() {
        let vm = ConnectionViewModel()
        var data = ImuData()
        data.accelX = 1.234
        data.gyroZ = -0.567
        data.quatW = 0.999
        vm.handle(.imu(data))
        #expect(vm.imu.accelX == 1.234)
        #expect(vm.imu.gyroZ == -0.567)
        #expect(vm.imu.quatW == 0.999)
    }

    @Test func bluetoothStateChanged_updates_state() {
        let vm = ConnectionViewModel()
        vm.handle(.bluetoothStateChanged(.poweredOff))
        #expect(vm.bluetoothState == .poweredOff)
    }
}
