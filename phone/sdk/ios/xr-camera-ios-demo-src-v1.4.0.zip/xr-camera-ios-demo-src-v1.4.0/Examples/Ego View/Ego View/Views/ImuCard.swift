import SwiftUI
import XRCamera

/// 加速度 / 角速度 / 四元数 / 温度（3 位小数）。
/// 数据来自 SDK `.imu(ImuData)` 事件，连接成功后由 VR 经 BLE `imu_info` 推送。
struct ImuCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            row("加速度(m/s²): ", [vm.imu.accelX, vm.imu.accelY, vm.imu.accelZ])
            row("角速度(rad/s): ", [vm.imu.gyroX, vm.imu.gyroY, vm.imu.gyroZ])
            // E2 不支持四元数与温度。
            if !vm.isE2 {
                row("四元数: ", [vm.imu.quatX, vm.imu.quatY, vm.imu.quatZ, vm.imu.quatW])
                row("温度(℃): ", [vm.imu.temperature])
            }
        }
        .font(.system(size: 12))
        .foregroundStyle(theme.textDim)
        .xrCard(theme)
    }

    /// 标签右对齐定宽 + 各值右对齐定宽，逗号分隔。
    private func row(_ label: String, _ values: [Double]) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 0) {
            Text(label).frame(width: 92, alignment: .trailing)
            ForEach(Array(values.enumerated()), id: \.offset) { offset, value in
                Text(String(format: "%.3f", value))
                    .frame(width: 48, alignment: .trailing)
                if offset < values.count - 1 {
                    Text(", ")
                }
            }
        }
    }
}
