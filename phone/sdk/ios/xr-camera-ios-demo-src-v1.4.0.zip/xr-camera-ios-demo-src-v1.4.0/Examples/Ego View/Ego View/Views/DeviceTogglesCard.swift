import SwiftUI
import XRCamera

/// 设备开关卡（E6 专属）：手势追踪 / 投影 / USB 模式。
/// 开关状态取自 `DeviceInfo`（VR 推送回显）；手势与 USB 修改需重启生效，
/// 手势 → 重启 APP，USB → 重启设备；投影即时生效。
struct DeviceTogglesCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    /// 待确认的开关动作（确认后才真正下发；取消则回弹，由 DeviceInfo 回显驱动）。
    @State private var pending: PendingToggle?

    private enum PendingToggle: Identifiable, Hashable {
        case hand(Bool)
        case usb(Bool)
        var id: Int { hashValue }
    }

    var body: some View {
        VStack(spacing: 0) {
            // 手势追踪：需重启 APP 生效，弹窗确认后 设置 + 重启 + 断开。
            toggleRow("手势追踪", Binding(
                get: { vm.deviceInfo.handEnabled ?? false },
                set: { pending = .hand($0) }))
            divider
            // 投影：即时生效，直接下发。
            toggleRow("投影", Binding(
                get: { vm.deviceInfo.projectEnabled ?? false },
                set: { vm.setProjectEnabled($0) }))
            divider
            // USB 模式：需重启设备生效，弹窗确认后 设置 + 重启 + 断开。
            toggleRow("USB 模式", Binding(
                get: { vm.deviceInfo.usbEnabled ?? false },
                set: { pending = .usb($0) }))
        }
        .xrCard(theme, padding: 0)
        .disabled(!vm.isConnected)
        .opacity(vm.isConnected ? 1 : 0.4)
        .alert(item: $pending) { action in
            alert(for: action)
        }
    }

    private var divider: some View {
        Divider().background(theme.border).padding(.horizontal, 14)
    }

    private func toggleRow(_ title: String, _ binding: Binding<Bool>) -> some View {
        HStack(spacing: 12) {
            Text(title)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(theme.text)
            Spacer()
            Toggle("", isOn: binding)
                .labelsHidden()
                .tint(theme.highlight)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
    }

    // MARK: - 二次确认弹窗

    private func alert(for action: PendingToggle) -> Alert {
        switch action {
        case .hand(let enabled):
            return Alert(
                title: Text("手势追踪"),
                message: Text("修改手势追踪需重启 VR APP，是否立即重启？"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .default(Text("立即重启")) {
                    vm.setHandEnabled(enabled)
                    vm.restartApp()
                    vm.disconnect()
                }
            )
        case .usb(let enabled):
            return Alert(
                title: Text("USB 模式"),
                message: Text("修改 USB 模式需重启设备，是否立即重启？"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .default(Text("立即重启")) {
                    vm.setUsbMode(enabled)
                    vm.restartDevice()  // 内含发送后断开。
                }
            )
        }
    }
}
