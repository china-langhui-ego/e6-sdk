import SwiftUI
import XRCamera

/// 设备名/电量/BLE-WS-Sync 点/WiFi/SN/存储。
struct StatusBarCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 12) {
                Text(vm.connectedDeviceName ?? "SXR_1")
                Text("电量: \(vm.deviceInfo.battery.map(String.init) ?? "--")")
                statusDot("BLE", color: bleColor, connecting: vm.connectionState == .connecting)
                statusDot("WS", color: wsColor, connecting: vm.isStartingPreview && !vm.wsConnected)
                // E2 不支持时间同步。
                if !vm.isE2 {
                    statusDot("Sync", color: syncColor, connecting: syncBreathing)
                    // 当前测量偏移。
                    if let off = vm.timeSyncState.offsetMs {
                        Text(String(format: "%.3fms", off))
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(syncColor)
                    }
                }
            }
            // 型号 / 固件版本（未回报前隐藏整行）。
            if let modelVersion = modelVersionText {
                Text(modelVersion)
            }
            Text(wifiText)
                .foregroundStyle(wifiColor)
            HStack(spacing: 24) {
                Text("SN: \(vm.deviceInfo.sn ?? "--")")
                Text(storageText)
                // E2 不支持音量控制。
                if !vm.isE2 {
                    Text(volumeText)
                }
            }
            // 数据集目录（录制/分片回报的 VR 端保存路径）。
            if let dir = vm.deviceInfo.datasetDir, !dir.isEmpty {
                Text("Dataset: \(dir)")
                    .font(.system(size: 11, design: .monospaced))
                    .lineLimit(2)
            }
        }
        .font(.system(size: 12))
        .foregroundStyle(theme.textDim)
        .xrCard(theme)
    }

    private var bleColor: Color {
        switch vm.connectionState {
        case .connecting: theme.warning
        case .connected: theme.success
        default: theme.textDim
        }
    }
    /// WS 点：出帧=绿，拉流连接中=黄，其余灰。
    private var wsColor: Color {
        if vm.wsConnected { return theme.success }
        if vm.isStartingPreview { return theme.warning }
        return theme.textDim
    }
    /// Sync 点
    /// 在线模式采集中=绿（持续回归无黄过渡）、未开始=灰；
    /// 离线模式 stable/calibrated=绿、collecting/warming=黄、error=红、其余灰。
    private var syncColor: Color {
        let s = vm.timeSyncState
        if s.onlineSync {
            return s.status == .collecting ? theme.success : theme.textDim
        }
        switch s.status {
        case .stable, .calibrated: return theme.success
        case .collecting, .warming: return theme.warning
        case .error: return theme.danger
        default: return theme.textDim
        }
    }
    /// 呼吸动画仅离线模式采集中。
    private var syncBreathing: Bool {
        !vm.timeSyncState.onlineSync && vm.timeSyncState.status == .collecting
    }
    private var wifiText: String {
        if vm.wifiStatus == .failed { return "WiFi: 连接失败" }
        if let ip = vm.vrIp { return "WiFi: \(vm.deviceInfo.wifiSsid ?? "--")(\(ip))" }
        if vm.connectionState == .connecting || vm.connectionState == .connected {
            return "WiFi: 连接中..."
        }
        return "WiFi: \(vm.deviceInfo.wifiSsid ?? "--")"
    }
    private var wifiColor: Color {
        if vm.wifiStatus == .failed { return theme.danger }
        if vm.connectionState == .connecting || (vm.connectionState == .connected && vm.vrIp == nil) {
            return theme.warning
        }
        return theme.textDim
    }
    private var storageText: String {
        switch (vm.deviceInfo.storageUsedMb, vm.deviceInfo.storageTotalMb) {
        case let (u?, t?): return "存储: \(u)/\(t)MB"
        default: return "存储: --"
        }
    }
    /// 音量展示：当前/上限。
    private var volumeText: String {
        let v = vm.deviceInfo.volume.map(String.init) ?? "--"
        let max = vm.deviceInfo.maxVolume.map(String.init) ?? "--"
        return "音量: \(v)/\(max)"
    }
    /// 型号 / 固件版本（两字段均缺省时返回 nil 隐藏整行）。
    private var modelVersionText: String? {
        var parts: [String] = []
        if let model = vm.deviceInfo.deviceModel, !model.isEmpty { parts.append("型号: \(model)") }
        if let ver = vm.deviceInfo.vrVersion, !ver.isEmpty { parts.append("版本: \(ver)") }
        return parts.isEmpty ? nil : parts.joined(separator: "  ")
    }

    @ViewBuilder
    private func statusDot(_ label: String, color: Color, connecting: Bool = false) -> some View {
        HStack(spacing: 4) {
            StatusDot(color: color, isConnecting: connecting)
            Text(label)
        }
    }
}
