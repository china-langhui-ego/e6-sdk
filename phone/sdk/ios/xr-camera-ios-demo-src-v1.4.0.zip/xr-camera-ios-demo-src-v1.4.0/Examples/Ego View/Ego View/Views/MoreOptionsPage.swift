import SwiftUI
import XRCamera

/// 更多/设置页：
/// 通用设置（语言）/ 录制设置（切片时长 + 分片上传地址）/ 设备管理（清除数据集、关机、重启、升级）。
struct MoreOptionsPage: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    /// 切片时长选项。
    private static let durationOptions = [1, 5, 10, 30, 60]

    @State private var uploadUrlText = ""
    @State private var isSavingUrl = false
    @State private var savedUrl: String?
    @State private var confirmAction: ConfirmAction?

    /// 危险操作二次确认。
    private enum ConfirmAction: Identifiable {
        case deleteData, shutdown, reboot, restartApp, upgrade
        var id: Int { hashValue }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 6) {
                sectionHeader("通用设置")
                generalCard
                    .padding(.bottom, 18)

                // 录制设置为 E6 专属（E2 无切片/上传能力）。
                if !vm.isE2 {
                    sectionHeader("录制设置")
                    recordCard
                        .padding(.bottom, 18)
                }

                sectionHeader("设备管理")
                actionsCard
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 24)
        }
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("更多")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            uploadUrlText = vm.deviceInfo.uploadUrl ?? ""
            vm.refreshSettings()
        }
        .onChange(of: vm.deviceInfo.uploadUrl) { url in
            if let url { uploadUrlText = url }
        }
        .alert("提示", isPresented: errorAlertPresented) {
            Button("确定", role: .cancel) { vm.lastError = nil }
        } message: {
            Text(vm.lastError ?? "")
        }
        .background(alertAnchor)
    }

    // MARK: - 弹窗挂载

    private var errorAlertPresented: Binding<Bool> {
        Binding(get: { vm.lastError != nil }, set: { if !$0 { vm.lastError = nil } })
    }

    /// 确认弹窗挂载点（与错误 alert 分离，避免同视图多 alert 冲突）。
    private var alertAnchor: some View {
        Color.clear
            .frame(height: 0)
            .alert(item: $confirmAction) { action in
                alert(for: action)
            }
    }

    // MARK: - 分组标题

    private func sectionHeader(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(theme.text)
            .padding(.horizontal, 4)
            .padding(.bottom, 4)
    }

    // MARK: - 通用设置（语言）

    private var generalCard: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Text("语言")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(theme.text)
                Spacer()
                Picker("语言", selection: languageBinding) {
                    Text("中文").tag("zh")
                    Text("English").tag("en")
                }
                .pickerStyle(.menu)
                .tint(theme.text)
                .frame(width: 140)
                .background(theme.accent, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
        }
        .xrCard(theme, padding: 0)
    }

    private var languageBinding: Binding<String> {
        Binding(
            get: { vm.deviceInfo.language ?? "zh" },
            set: { vm.setLanguage($0) }
        )
    }

    // MARK: - 录制设置

    private var recordCard: some View {
        VStack(spacing: 0) {
            // 切片时长
            HStack(spacing: 12) {
                Text("切片时长")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(theme.text)
                Spacer()
                Picker("切片时长", selection: durationBinding) {
                    ForEach(Self.durationOptions, id: \.self) { m in
                        Text("\(m) 分钟").tag(m)
                    }
                }
                .pickerStyle(.menu)
                .tint(theme.text)
                .frame(width: 140)
                .background(theme.accent, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)

            Divider().background(theme.border).padding(.horizontal, 14)

            // 分片上传地址
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("分片上传地址")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(theme.text)
                    Spacer()
                    if let url = vm.deviceInfo.uploadUrl, !url.isEmpty {
                        Text("已设置")
                            .font(.system(size: 11))
                            .foregroundStyle(theme.success)
                    }
                }
                TextField("请输入上传地址", text: $uploadUrlText)
                    .textFieldStyle(XRFieldStyle(theme: theme))
                    .font(.system(size: 14, design: .monospaced))
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                Button {
                    // 归一化：反斜杠按正斜杠处理（VR 端 new URL() 遇 '\' 会直接抛异常）。
                    let trimmed = uploadUrlText
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                        .replacingOccurrences(of: "\\", with: "/")
                    guard !trimmed.isEmpty else {
                        vm.lastError = "请输入上传地址"
                        return
                    }
                    guard trimmed.hasPrefix("http://") || trimmed.hasPrefix("https://") else {
                        vm.lastError = "地址需以 http:// 或 https:// 开头"
                        return
                    }
                    uploadUrlText = trimmed   // 回填归一化后的值，所见即所存
                    isSavingUrl = true
                    vm.setUploadUrl(trimmed) { url in
                        isSavingUrl = false
                        savedUrl = url        // nil 时 VM 已弹错误提示，不再弹成功
                    }
                } label: {
                    Text(isSavingUrl ? "保存中…" : "保存")
                        .font(.system(size: 14))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 40)
                        .background(theme.highlight, in: RoundedRectangle(cornerRadius: theme.buttonCornerRadius))
                }
                .disabled(isSavingUrl)
                .padding(.top, 2)
                // 成功提示以 VR 读回为准（等待回包期间按钮显示“保存中…”）。
                .alert("已保存", isPresented: Binding(
                    get: { savedUrl != nil },
                    set: { if !$0 { savedUrl = nil } })) {
                    Button("好", role: .cancel) {}
                } message: {
                    Text("分片上传地址：\(savedUrl ?? "")")
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
        }
        .xrCard(theme, padding: 0)
    }

    private var durationBinding: Binding<Int> {
        Binding(
            get: { vm.deviceInfo.chunkDurationMin ?? Self.durationOptions.first ?? 5 },
            set: { vm.setChunkDuration($0) }
        )
    }

    // MARK: - 设备管理

    private var actionsCard: some View {
        VStack(spacing: 0) {
            actionTile(icon: "trash", title: "清除数据集",
                       description: "删除 VR 设备上的所有录制数据（不可恢复）",
                       iconColor: theme.danger) {
                guardNotRecording { confirmAction = .deleteData }
            }
            divider
            actionTile(icon: "power", title: "关机",
                       description: "远程关闭 VR 设备",
                       iconColor: theme.warning) {
                guardNotRecording { confirmAction = .shutdown }
            }
            divider
            actionTile(icon: "arrow.clockwise", title: "重启 VR 设备",
                       description: "远程重启 VR 设备",
                       iconColor: theme.text) {
                guardNotRecording { confirmAction = .reboot }
            }
            divider
            actionTile(icon: "arrow.triangle.2.circlepath", title: "重启 APP",
                       description: "重启设备端应用",
                       iconColor: theme.text) {
                guardNotRecording { confirmAction = .restartApp }
            }
            // 升级为 E2 SSC 前缀才显示。
            if vm.isE2 {
                divider
                Button {
                    vm.checkUpgrade()
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            actionIcon("arrow.down.circle", color: theme.textDim)
                            Text("检查升级")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(theme.text)
                            Spacer()
                            // 整行可点即触发检查，右侧文字仅作操作提示（非独立按钮）。
                            Text("检查")
                                .font(.system(size: 13))
                                .foregroundStyle(theme.highlight)
                            if let result = vm.upgradeCheckResult {
                                Button("升级") { confirmAction = .upgrade }
                                    .font(.system(size: 13))
                                    .foregroundStyle(theme.warning)
                                    .disabled(result != "ok")
                            }
                        }
                        if let result = vm.upgradeCheckResult {
                            Text(result == "ok" ? "有可用更新" : result)
                                .font(.system(size: 12))
                                .foregroundStyle(result == "ok" ? theme.success : theme.textDim)
                                .padding(.leading, 44)
                        }
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .contentShape(Rectangle())
                }
                .buttonStyle(PressableRowStyle())
                .disabled(!vm.isConnected)
                .opacity(vm.isConnected ? 1 : 0.4)

                // USB 模式切换（time sync 串口 / 常规；E2 专属，点按即切换）。
                divider
                Button {
                    vm.switchUsbDeviceMode()
                } label: {
                    HStack(spacing: 10) {
                        actionIcon("cable.connector", color: theme.textDim)
                        Text("USB 模式")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(theme.text)
                        Spacer()
                        Text("切换")
                            .font(.system(size: 13))
                            .foregroundStyle(theme.highlight)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .contentShape(Rectangle())
                }
                .buttonStyle(PressableRowStyle())
                .disabled(!vm.isConnected)
                .opacity(vm.isConnected ? 1 : 0.4)
            }
        }
        .xrCard(theme, padding: 0)
    }

    private var divider: some View {
        Divider().background(theme.border).padding(.horizontal, 14)
    }

    private func actionIcon(_ name: String, color: Color) -> some View {
        Image(systemName: name)
            .font(.system(size: 18))
            .foregroundStyle(color)
            .frame(width: 36, height: 36)
            .background(theme.accent, in: RoundedRectangle(cornerRadius: 8))
    }

    private func actionTile(icon: String, title: String, description: String,
                            iconColor: Color, onTap: @escaping () -> Void) -> some View {
        Button(action: onTap) {
            HStack(spacing: 10) {
                actionIcon(icon, color: iconColor)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(theme.text)
                    Text(description)
                        .font(.system(size: 13))
                        .foregroundStyle(theme.textDim)
                        .multilineTextAlignment(.leading)
                }
                Spacer()
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            // 整行参与命中测试（含 Spacer/留白区），否则只有图标/文字可点。
            .contentShape(Rectangle())
        }
        .buttonStyle(PressableRowStyle())
        .disabled(!vm.isConnected)
        .opacity(vm.isConnected ? 1 : 0.4)
    }

    /// 行按钮按压反馈（半透明示压）；配合 `.contentShape` 实现整行点击。
    private struct PressableRowStyle: ButtonStyle {
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .opacity(configuration.isPressed ? 0.6 : 1)
        }
    }

    /// 录制中禁止危险操作。
    private func guardNotRecording(_ action: () -> Void) {
        if vm.isRecording {
            vm.lastError = "录制进行中，无法进行该操作"
        } else {
            action()
        }
    }

    // MARK: - 二次确认弹窗

    private func alert(for action: ConfirmAction) -> Alert {
        switch action {
        case .deleteData:
            return Alert(
                title: Text("清除数据集"),
                message: Text("删除后无法恢复，是否继续？"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .destructive(Text("确认删除")) {
                    vm.deleteData()
                }
            )
        case .shutdown:
            return Alert(
                title: Text("关闭 VR 设备"),
                message: Text("设备关机后将停止运行，若需再次使用，请手动按电源键重启。"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .destructive(Text("关机")) {
                    vm.shutdownDevice()
                }
            )
        case .reboot:
            return Alert(
                title: Text("重启 VR 设备"),
                message: Text("设备将重新启动，期间 APP 会断开连接。"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .default(Text("立即重启")) {
                    vm.restartDevice()
                }
            )
        case .restartApp:
            return Alert(
                title: Text("重启 APP"),
                message: Text("设备端应用将重新启动，期间连接会短暂断开。"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .default(Text("重启应用")) {
                    vm.restartApp()
                }
            )
        case .upgrade:
            return Alert(
                title: Text("升级确认"),
                message: Text("是否进行升级？"),
                primaryButton: .cancel(Text("取消")),
                secondaryButton: .default(Text("升级")) {
                    vm.startUpgrade()
                }
            )
        }
    }
}
