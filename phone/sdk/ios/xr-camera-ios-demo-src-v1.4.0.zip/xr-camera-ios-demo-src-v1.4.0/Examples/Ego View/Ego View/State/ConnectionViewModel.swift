import Foundation
import UIKit
import SwiftUI
import Combine
import XRCamera

/// 配网阶段的状态枢纽。
/// 项目默认 MainActor 隔离，故本类天然 @MainActor。
final class ConnectionViewModel: ObservableObject {

    let client = XRCameraClient()

    // 连接 / 扫描
    @Published private(set) var connectionState: ConnectionState = .idle
    @Published private(set) var scannedDevices: [XrDevice] = []

    // 网络 / 设备
    @Published private(set) var wifiStatus: WifiStatus = .idle
    @Published private(set) var vrIp: String?
    @Published private(set) var deviceInfo = DeviceInfo()
    @Published private(set) var connectedDeviceName: String?

    // IMU（BLE imu_info 推送；连接后展示）
    @Published private(set) var imu = ImuData()

    // 视频预览
    @Published private(set) var videoStats = VideoStats()
    @Published private(set) var isPlaying = false
    /// WS 拉流状态（状态栏 WS 点：出帧=绿、连接中=黄、断开=灰）。
    @Published private(set) var wsConnected = false
    @Published private(set) var isStartingPreview = false
    /// 时间同步状态。
    @Published private(set) var timeSyncState = TimeSyncState()
    /// 当前摄像头组（Picker 双向绑定；switchGroup 同步到 client）。
    @Published var selectedGroup: CameraGroup = .tracking
    @Published private(set) var lastScreenshot: UIImage?
    @Published private(set) var recordingPath: String?

    // 录制
    @Published private(set) var isRecording = false
    /// 正在准备录制（start_record 已下发、recording_started 未回）；按钮琥珀色，可取消。
    @Published private(set) var isArmingRecording = false
    /// 录制完成（recording_stopped 携带保存路径）→ 弹录制成功对话框；视图消费后置 nil。
    @Published var recordingCompletedPath: String?
    /// 录制命令失败（cmd_response result≠ok）→ 弹录制错误对话框；视图消费后置 nil。
    @Published var recordingError: String?
    /// 升级检查结果（"ok" 表可升级，其他为错误描述）。
    @Published private(set) var upgradeCheckResult: String?

    // 蓝牙适配器状态（事件驱动；连接前后均可能变化）
    @Published private(set) var bluetoothState: BluetoothState?

    // 手柄 / 腕部相机（E6 + ES202）
    /// 左右手柄状态镜像。
    @Published private(set) var handshankLeft: HandshankSideState?
    @Published private(set) var handshankRight: HandshankSideState?
    /// 腕部双路流地址镜像。
    @Published private(set) var wristStreams = WristStreams()
    /// 腕部双侧播放态。
    @Published private(set) var wristPlayback = WristPlayback()
    /// 腕部详情（get_wrist_detail 应答；nil=未拉取/未就绪清空）。
    @Published private(set) var wristDetails: [HandshankSide: WristDetail] = [:]
    /// 腕部 IMU 最近一帧（wrist_imu_info 约 1Hz，详情页开启期间更新）。
    @Published private(set) var wristImu: [HandshankSide: WristImuData] = [:]

    // 错误 / 提示（视图可读写以清除）
    @Published var lastError: String?

    /// 上传地址保存回执：等 VR cmd_response 读回后触发一次（参数=VR 实际保存的 url，nil=失败/超时）。
    private var uploadUrlSaveWaiter: ((String?) -> Void)?
    /// 上传地址保存轮次：每轮保存递增，超时兜底按代号校验归属，防旧定时器消费新一轮的 waiter。
    private var uploadUrlSaveGeneration = 0

    // WiFi 凭据（持久化）
    @Published var ssid: String = UserDefaults.standard.string(forKey: "ego.wifi.ssid") ?? ""
    @Published var password: String = UserDefaults.standard.string(forKey: "ego.wifi.password") ?? ""

    /// 当前选中设备（connect 时设置；internal 供测试注入）。
    var selectedDevice: XrDevice?

    private var eventsTask: Task<Void, Never>?
    private var scanTask: Task<Void, Never>?

    var isScanning: Bool { connectionState == .scanning }
    var isConnected: Bool { connectionState == .connected }
    /// E2 设备。
    var isE2: Bool { deviceInfo.deviceModel?.hasPrefix("SSC") == true }

    /// App 级单例实际不会走到释放；取消仅为不留悬挂 Task（AsyncStream 感知取消，
    /// cancel 后 for await 结束并触发 SDK 侧 onTermination 注销 continuation）。
    deinit {
        eventsTask?.cancel()
        scanTask?.cancel()
    }

    // MARK: - 事件流

    /// 订阅 SDK 事件流（幂等，仅订阅一次）。
    func startObservingEvents() {
        guard eventsTask == nil else { return }
        eventsTask = Task { [weak self] in
            // 全程弱引用：不在循环外升级 self，避免 VM→Task→VM 永久自引用环。
            guard let stream = await self?.client.events() else { return }
            for await event in stream {
                self?.handle(event)
            }
        }
    }

    // MARK: - 扫描

    func scan() {
        guard !isScanning else { return }
        scannedDevices = []
        scanTask?.cancel()
        scanTask = Task { [weak self] in
            guard let self else { return }
            let stream = await self.client.startScan()
            for await device in stream {
                self.mergeDevice(device)
            }
        }
    }

    // MARK: - 连接 / 断开

    func connect(_ device: XrDevice) {
        selectedDevice = device
        Task { [weak self] in
            guard let self else { return }
            do {
                try await self.client.connect(device, ssid: ssid, password: password)
            } catch {
                self.lastError = Self.describe(error)
            }
        }
    }

    func disconnect() {
        Task { [weak self] in await self?.client.disconnect() }
    }

    // MARK: - 视频预览

    /// 开始预览（onAppear / 连接就绪时调用）。group 取 selectedGroup。
    ///
    /// 自动调用时机（onAppear / onChange(vrIp)）可能在 vrIp 尚未到达、或断开后 vrIp 已清空时触发；
    /// 此时静默跳过（不弹错）。仅就绪（已连接且有 IP）才真正下发。
    /// E2（SSC）设备传 `second` 时双目分屏预览（左目→preview、右目→second）；E6 忽略。
    func startPreview(_ preview: XRCameraPreview, second: XRCameraPreview? = nil) {
        guard isConnected, let ip = vrIp, !ip.isEmpty else { return }
        isStartingPreview = true
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.startPreview(self.selectedGroup, in: preview, second: second) }
            catch { self.lastError = Self.describe(error) }
            self.isStartingPreview = false
        }
    }

    func stopPreview() {
        Task { [weak self] in await self?.client.stopPreview() }
    }

    /// 切换摄像头组（Picker 绑定已更新 selectedGroup；此处下发并重连 WS）。
    /// wrist 组兜底守卫：能力位非 true 时拒绝（菜单已隐藏，此为双保险）。
    func switchGroup(_ group: CameraGroup) {
        let previous = selectedGroup
        selectedGroup = group
        if group == .wrist && deviceInfo.wristSupported != true {
            lastError = "当前设备不支持 wrist 组"
            selectedGroup = previous
            return
        }
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.switchGroup(group) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 截图（结果落 lastScreenshot）。
    func takeScreenshot() {
        Task { [weak self] in
            guard let self else { return }
            if let img = await self.client.takeScreenshot() {
                self.lastScreenshot = img
            }
        }
    }

    // MARK: - 录制

    /// 开始录制。
    func startRecording() {
        guard isConnected, !isRecording, !isArmingRecording else { return }
        isArmingRecording = true
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.startRecording() }
            catch {
                self.isArmingRecording = false
                self.lastError = Self.describe(error)
            }
        }
    }

    /// 停止录制（录制中或准备中均可取消）。
    func stopRecording() {
        guard isRecording || isArmingRecording else { return }
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.stopRecording() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    // MARK: - 设备管理 / 录制配置

    /// 音量 +1（VR 端达上限时不发；E6 专属）。
    func increaseVolume() {
        Task { [weak self] in try? await self?.client.increaseVolume() }
    }

    /// 音量 -1（VR 端达下限时不发；E6 专属）。
    func decreaseVolume() {
        Task { [weak self] in try? await self?.client.decreaseVolume() }
    }

    /// 开关手势追踪（需重启 VR APP 后生效，由调用方弹窗确认后组合 restartApp）。
    func setHandEnabled(_ enabled: Bool) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setHandEnabled(enabled) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 开关手势/手柄投影（即时生效）。
    func setProjectEnabled(_ enabled: Bool) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setProjectEnabled(enabled) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 开关 USB 模式（mtp,adb / none；需重启设备后生效，由调用方弹窗确认后组合 restartDevice）。
    func setUsbMode(_ enabled: Bool) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setUsbMode(enabled: enabled) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 切换 USB 设备模式（time sync 串口 / 常规；E2 专属）。
    func switchUsbDeviceMode() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.switchUsbDeviceMode() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 设置切片时长（分钟；选项 5/10/30/60）。
    func setChunkDuration(_ minutes: Int) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setChunkDuration(minutes: minutes) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 设置分片上传地址（`saved` 在 VR `cmd_response` 读回后触发；参数 nil=写入失败或超时）。
    func setUploadUrl(_ url: String, saved: ((String?) -> Void)? = nil) {
        uploadUrlSaveGeneration += 1
        let generation = uploadUrlSaveGeneration
        uploadUrlSaveWaiter = saved
        Task { [weak self] in
            guard let self else { return }
            do {
                try await self.client.setUploadUrl(url)
            } catch {
                self.lastError = Self.describe(error)
                self.finishUploadUrlSave(nil)
                return
            }
            // 兜底：VR 未回包 5s 超时按失败处理，避免按钮卡在“保存中”。
            // 代号不一致=本轮保存已被新一轮覆盖，旧定时器作废（不得消费新 waiter）。
            Task { [weak self] in
                try? await Task.sleep(nanoseconds: 5_000_000_000)
                guard let self, generation == self.uploadUrlSaveGeneration,
                      self.uploadUrlSaveWaiter != nil else { return }
                self.lastError = "保存超时，未收到设备确认"
                self.finishUploadUrlSave(nil)
            }
        }
    }

    private func finishUploadUrlSave(_ url: String?) {
        guard let waiter = uploadUrlSaveWaiter else { return }
        uploadUrlSaveWaiter = nil
        waiter(url)
    }

    /// 设置 VR 系统语言（zh/en）。
    func setLanguage(_ language: String) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setLanguage(language) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 关机后断开连接。
    func shutdownDevice() {
        Task { [weak self] in
            guard let self else { return }
            try? await self.client.shutdown()
            await self.client.disconnect()
        }
    }

    /// 重启设备后断开连接。
    func restartDevice() {
        Task { [weak self] in
            guard let self else { return }
            try? await self.client.reboot()
            await self.client.disconnect()
        }
    }

    /// 重启 VR APP。
    func restartApp() {
        Task { [weak self] in try? await self?.client.restartApp() }
    }

    /// 清除数据集。
    func deleteData() {
        Task { [weak self] in try? await self?.client.deleteData() }
    }

    /// 检查升级（结果走 upgradeCheckResult）。
    func checkUpgrade() {
        upgradeCheckResult = nil
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.checkUpgrade() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 开始升级。
    func startUpgrade() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.startUpgrade() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    // MARK: - 时间同步（E6 专属；PC 时间同步服务可达时有效）

    /// 偏移测试：单次 NTP 交换，结果经 `timeSyncState.offsetMs` 回传。
    func offsetTest() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.offsetTest() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 手动开始 NTP 时间同步采集。
    func startSync() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.startSync() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 停止时间同步采集。
    func cancelSync() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.cancelSync() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 进入更多页时批量刷新配置回显（切片时长/上传地址/语言）。
    func refreshSettings() {
        Task { [weak self] in
            guard let self else { return }
            try? await self.client.getChunkDuration()
            try? await self.client.getUploadUrl()
            try? await self.client.getLanguage()
        }
    }

    // MARK: - 手柄 / 腕部相机（E6 + ES202）

    /// 刷新手柄状态（连接后 SDK 已按机型自动补拉一次，需要刷新时调用）。
    func getHandshankStatus() {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.getHandshankStatus() }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 绑定指定侧手柄（结果经 handshankStatus 推送更新；失败弹 handshankBondError）。
    func bondHandshank(_ side: HandshankSide) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.bondHandshank(side) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 解除指定侧手柄绑定。
    func unbondHandshank(_ side: HandshankSide) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.unbondHandshank(side) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 拉取单侧腕部详情（结果走 wristDetails；未就绪时该侧清空）。
    func getWristDetail(_ side: HandshankSide) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.getWristDetail(side) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 开关腕部 IMU 推送（详情页进入开、离开关）。
    func setWristImuEnabled(_ enabled: Bool) {
        Task { [weak self] in
            guard let self else { return }
            do { try await self.client.setWristImuEnabled(enabled) }
            catch { self.lastError = Self.describe(error) }
        }
    }

    /// 设置腕部双路预览渲染目标（wrist 组进入时传左右视图、离开传 nil）。
    func setWristSurfaces(left: XRCameraPreview?, right: XRCameraPreview?) {
        Task { [weak self] in await self?.client.setWristSurfaces(left: left, right: right) }
    }

    // MARK: - WiFi 凭据持久化

    func saveWifiConfig() {
        UserDefaults.standard.set(ssid, forKey: "ego.wifi.ssid")
        UserDefaults.standard.set(password, forKey: "ego.wifi.password")
    }

    // MARK: - 事件 → 状态（纯逻辑，可单测）

    func handle(_ event: XRCameraEvent) {
        switch event {
        case .connectionChanged(let state):
            connectionState = state
            if state == .connected {
                connectedDeviceName = selectedDevice?.name
            }
        case .wifiStatus(let value):
            wifiStatus = value
        case .vrIpAddress(let ip):
            vrIp = ip
        case .deviceInfo(let info):
            mergeDeviceInfo(info)
            // set_upload_url 的 cmd_response 读回（VR 回显 url）→ 触发保存回执。
            if info.uploadUrl != nil { finishUploadUrlSave(info.uploadUrl) }
        case .error(let err):
            lastError = Self.describe(err)
        case .disconnected:
            vrIp = nil
            connectedDeviceName = nil
            deviceInfo = DeviceInfo()
            imu = ImuData()
            // 播放状态必须随断开复位（SDK 会先发 playingChanged(false)，此处兜底），
            // 否则重连后按钮残留「停止预览」而实际无预览。
            isPlaying = false
            wsConnected = false
            isStartingPreview = false
            videoStats = VideoStats()
            isRecording = false
            isArmingRecording = false
            // 手柄/腕部状态随断开全清（SDK resetWristSession 已发复位事件，此处兜底）。
            // 停在 wrist 组则回落 RGB（断连后能力位未知，避免选中项在菜单中不可见）。
            if selectedGroup == .wrist { selectedGroup = .rgb }
            handshankLeft = nil
            handshankRight = nil
            wristStreams = WristStreams()
            wristPlayback = WristPlayback()
            wristDetails = [:]
            wristImu = [:]
        case .imu(let data):
            imu = data
        case .bluetoothStateChanged(let state):
            bluetoothState = state
        case .stats(let s):
            videoStats = s
        case .playingChanged(let playing):
            isPlaying = playing
            if !playing { wsConnected = false }
        case .firstFrameDecoded:
            isPlaying = true
            wsConnected = true
            // 出帧即拉流成功，提前结束「连接中」（不等 startPreview 返回，消除绿点呼吸窗口）。
            isStartingPreview = false
        case .recordingPath(let path):
            recordingPath = path
        case .chunkSaved(let path):
            recordingPath = path
        case .recordingChanged(let recording, let path, _, _):
            isArmingRecording = false
            isRecording = recording
            if let path, !path.isEmpty {
                recordingPath = path
                if !recording { recordingCompletedPath = path }
            }
        case .recordingError(let error):
            isArmingRecording = false
            isRecording = false
            recordingError = error
        case .upgradeCheckResult(let result):
            upgradeCheckResult = result
        case .commandFailed(let cmd, let error):
            lastError = "\(cmd): \(error)"
        case .handTrackingRestartRequired(let enabled):
            // 手势状态变化，重启 APP 后生效。
            lastError = "手势追踪已\(enabled ? "开启" : "关闭")，重启 APP 后生效"
        case .usbModeChanged(let enabled):
            // USB 模式变化，重启设备后生效。
            lastError = "USB 已\(enabled ? "开启" : "关闭")，重启后生效"
        case .timeSync(let state):
            timeSyncState = state
        case .handshankStatus(let side, let state):
            if side == .left { handshankLeft = state } else { handshankRight = state }
        case .handshankBondError(let side, let error):
            lastError = "手柄\(side == .left ? "左" : "右")绑定失败: \(error)"
        case .wristDetail(let side, let detail):
            if let detail { wristDetails[side] = detail } else { wristDetails.removeValue(forKey: side) }
        case .wristImu(let side, let data):
            wristImu[side] = data
        case .wristStreamsChanged(let streams):
            wristStreams = streams
        case .wristPlaybackChanged(let playback):
            wristPlayback = playback
        }
    }

    // MARK: - 合并

    /// iOS 上序列号/RSSI 可能在后续广播包补全；按 id 合并。
    private func mergeDevice(_ device: XrDevice) {
        if let idx = scannedDevices.firstIndex(where: { $0.id == device.id }) {
            var existing = scannedDevices[idx]
            existing.rssi = device.rssi
            if !device.serialNumber.isEmpty { existing.serialNumber = device.serialNumber }
            if existing.name.isEmpty { existing.name = device.name }
            scannedDevices[idx] = existing
        } else {
            scannedDevices.append(device)
        }
    }

    /// BLE 推送的 deviceInfo 各字段部分可选，按非 nil 增量合并。
    private func mergeDeviceInfo(_ info: DeviceInfo) {
        var d = deviceInfo
        if let v = info.deviceModel { d.deviceModel = v }
        if let v = info.battery { d.battery = v }
        if let v = info.sn { d.sn = v }
        if let v = info.wifiSsid { d.wifiSsid = v }
        if let v = info.wifiIp { d.wifiIp = v }
        if let v = info.storageTotalMb { d.storageTotalMb = v }
        if let v = info.storageUsedMb { d.storageUsedMb = v }
        if let v = info.volume { d.volume = v }
        if let v = info.maxVolume { d.maxVolume = v }
        if let v = info.projectEnabled { d.projectEnabled = v }
        if let v = info.handEnabled { d.handEnabled = v }
        if let v = info.usbEnabled { d.usbEnabled = v }
        if let v = info.chunkDurationMin { d.chunkDurationMin = v }
        if let v = info.uploadUrl { d.uploadUrl = v }
        if let v = info.language { d.language = v }
        if let v = info.recording { d.recording = v }
        if let v = info.wristSupported { d.wristSupported = v }
        if let v = info.es202Handshank { d.es202Handshank = v }
        deviceInfo = d
    }

    // MARK: - 错误文案

    static func describe(_ error: Error) -> String {
        guard let err = error as? XRCameraError else {
            return "连接失败: \(error.localizedDescription)"
        }
        switch err {
        case .bluetoothUnavailable: return "蓝牙不可用"
        case .bluetoothPoweredOff: return "蓝牙未开启，请在系统设置中打开蓝牙"
        case .bluetoothUnauthorized: return "未授权使用蓝牙，请在系统设置开启蓝牙权限"
        case .bluetoothUnsupported: return "当前设备不支持蓝牙"
        case .serviceNotFound: return "未发现目标蓝牙服务"
        case .characteristicNotFound(let c): return "未找到蓝牙特征: \(c)"
        case .connectFailed(let underlying): return "连接失败: \(underlying)"
        case .wifiFailed: return "WiFi 连接失败，请检查凭据或网络"
        case .websocketFailed(let underlying): return "WebSocket 连接失败: \(underlying)"
        case .decoderFailed(let underlying): return "视频解码失败: \(underlying)"
        case .notConnected: return "设备未连接"
        case .timeout: return "操作超时"
        case .unsupportedLanguage(let lang): return "不支持的语言: \(lang)（仅支持 zh/en）"
        case .underlying(let message): return message
        }
    }
}
