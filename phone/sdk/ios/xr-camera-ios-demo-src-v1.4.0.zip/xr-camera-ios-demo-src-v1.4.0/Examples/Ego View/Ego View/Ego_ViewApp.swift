import SwiftUI

@main
struct Ego_ViewApp: App {
    @StateObject private var themeManager = ThemeManager()
    @StateObject private var connectionViewModel = ConnectionViewModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(themeManager) // 注入，方便子View能取到。按照类型匹配的，子View 获取变量名任意都可以。如果多次注入，按最内层优先。
                .environmentObject(connectionViewModel)
        }
    }
}
