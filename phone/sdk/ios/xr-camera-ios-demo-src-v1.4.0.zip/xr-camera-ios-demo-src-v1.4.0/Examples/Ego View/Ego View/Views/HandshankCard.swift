import SwiftUI
import XRCamera

/// 手柄状态卡（wristSupported == true 时显示于预览页）：
/// 左右各一列——绑定/连接/电量状态 + 绑定/解绑操作。
/// es202Handshank == false 时为普通手柄（无腕部相机），标题相应收窄。
struct HandshankCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    /// ES202 手柄（携带腕部相机）才显示腕部相关副标题。
    private var isES202: Bool { vm.deviceInfo.es202Handshank == true }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(isES202 ? "手柄 / 腕部相机" : "手柄", systemImage: "gamecontroller")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(theme.text)
            HStack(alignment: .top, spacing: 10) {
                sideCard(.left)
                sideCard(.right)
            }
        }
        .xrCard(theme)
        .onAppear { vm.getHandshankStatus() }
    }

    private func sideCard(_ side: HandshankSide) -> some View {
        let state = side == .left ? vm.handshankLeft : vm.handshankRight
        let bonded = state?.bonded ?? false
        return VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(side == .left ? "左手柄" : "右手柄")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(theme.text)
                Spacer()
                // 电量（VR 未上报时省略）
                if let battery = state?.battery {
                    Image(systemName: batteryIcon(battery))
                        .font(.system(size: 12))
                        .foregroundStyle(battery <= 20 ? theme.danger : theme.textDim)
                    Text("\(battery)%")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundStyle(theme.textDim)
                }
            }
            statusRow("绑定", ok: bonded)
            statusRow("连接", ok: state?.connected ?? false)
            if isES202 {
                statusRow("腕部", ok: state?.wifiConnected ?? false)
            }
            Button {
                bonded ? vm.unbondHandshank(side) : vm.bondHandshank(side)
            } label: {
                Text(bonded ? "解绑" : "绑定")
                    .font(.system(size: 13))
                    .foregroundStyle(bonded ? theme.danger : theme.highlight)
                    .frame(maxWidth: .infinity, minHeight: 32)
                    .background(theme.accent, in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(theme.border, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(!vm.isConnected)
        }
        .padding(10)
        .background(theme.background, in: RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(theme.border, lineWidth: 1))
    }

    private func statusRow(_ title: String, ok: Bool) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 12))
                .foregroundStyle(theme.textDim)
            Spacer()
            Image(systemName: ok ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 12))
                .foregroundStyle(ok ? theme.success : theme.textDim)
        }
    }

    private func batteryIcon(_ level: Int) -> String {
        switch level {
        case ..<20: "battery.25"      // iOS 13+ 经典名（*percent 后缀为 iOS 16+）
        case ..<50: "battery.50"
        case ..<80: "battery.75"
        default: "battery.100"
        }
    }
}
