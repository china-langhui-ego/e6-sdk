import SwiftUI

/// 所有 UI 颜色令牌的唯一来源。视图经 `@Environment(\.appTheme)` 读取，
/// 禁止在 `Theme/` 与 `Views/styles` 之外出现 `Color(hex:)` 或 `AppTheme.dark/.light`。
struct AppTheme: Sendable, Equatable {
    // 背景层级
    let background: Color   // scaffold
    let card: Color         // 卡片（ bgCard #1E293B）
    let accent: Color       // 次级填充/输入框/行底（ bgAccent #334155）
    let appBar: Color       // 顶栏（ appBarBg #1A2332）

    // 品牌与语义
    let highlight: Color    // 主按钮（ colorHighlight #E94560）—— 深浅一致
    let text: Color         // 主文本
    let textDim: Color      // 次要文本
    let border: Color       // 卡片/输入框边框
    let success: Color
    let warning: Color
    let danger: Color       // 深色下与 highlight 同；浅色加深红保证对比度

    // 度量
    let cornerRadius: CGFloat
    let buttonCornerRadius: CGFloat

    /// 深色：
    static let dark = AppTheme(
        background: Color(hex: 0x0F172A),
        card: Color(hex: 0x1E293B),
        accent: Color(hex: 0x334155),
        appBar: Color(hex: 0x1A2332),
        highlight: Color(hex: 0xE94560),
        text: Color(hex: 0xE2E8F0),
        textDim: Color(hex: 0x94A3B8),
        border: Color(hex: 0x334155),
        success: Color(hex: 0x4CAF50),
        warning: Color(hex: 0xFF9800),
        danger: Color(hex: 0xE94560),
        cornerRadius: 12,
        buttonCornerRadius: 20
    )

    /// 浅色：派生（sRGB 浅底 + 对比度达 WCAG AA 的文本/语义色）。
    static let light = AppTheme(
        background: Color(hex: 0xF1F5F9),
        card: Color(hex: 0xFFFFFF),
        accent: Color(hex: 0xE2E8F0),
        appBar: Color(hex: 0xE2E8F0),
        highlight: Color(hex: 0xE94560),
        text: Color(hex: 0x0F172A),
        textDim: Color(hex: 0x64748B),
        border: Color(hex: 0xE2E8F0),
        success: Color(hex: 0x2E9E52),
        warning: Color(hex: 0xE07A00),
        danger: Color(hex: 0xD12D4A),
        cornerRadius: 12,
        buttonCornerRadius: 20
    )
}

extension Color {
    /// `Color(hex: 0xRRGGBB)`，sRGB。
    init(hex: UInt32, alpha: Double = 1.0) {
        let r = Double((hex >> 16) & 0xFF) / 255.0
        let g = Double((hex >> 8) & 0xFF) / 255.0
        let b = Double(hex & 0xFF) / 255.0
        self.init(.sRGB, red: r, green: g, blue: b, opacity: alpha)
    }
}

// MARK: - Environment 注入

private struct AppThemeKey: EnvironmentKey {
    static let defaultValue: AppTheme = .dark
}

extension EnvironmentValues {
    var appTheme: AppTheme {
        get { self[AppThemeKey.self] }
        set { self[AppThemeKey.self] = newValue }
    }
}

/// 读取当前生效的 `@Environment(\.colorScheme)`（已被根视图 `preferredColorScheme` 覆盖）
/// 并向下转发，供 RootView 据其注入 `appTheme`。
struct ColorSchemeReader<Content: View>: View {
    @Environment(\.colorScheme) private var colorScheme
    @ViewBuilder var content: (ColorScheme) -> Content
    var body: some View { content(colorScheme) }
}
