import SwiftUI
import Combine

/// 外观偏好：自动（跟随系统）/ 浅色 / 深色。
enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var label: String {
        switch self {
        case .system: "自动"
        case .light: "浅色"
        case .dark: "深色"
        }
    }
}

/// 持有外观偏好（持久化），解析 SwiftUI `ColorScheme` 与 `AppTheme`。
/// 项目默认 MainActor 隔离，故本类天然 @MainActor（无需显式标注）。
final class ThemeManager: ObservableObject {

    @Published var mode: AppearanceMode // ObservableObject 配合 @Published（有变化，UI改动）

    private let defaultsKey = "ego.appearanceMode"

    init() {
        let raw = UserDefaults.standard.string(forKey: "ego.appearanceMode") ?? AppearanceMode.system.rawValue
        mode = AppearanceMode(rawValue: raw) ?? .system
    }

    /// 供根视图 `.preferredColorScheme(_:)`；nil = 跟随系统。
    func preferredColorScheme() -> ColorScheme? {
        switch mode {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }

    /// 按当前生效 colorScheme 解析主题令牌。
    func theme(for colorScheme: ColorScheme) -> AppTheme {
        colorScheme == .dark ? .dark : .light
    }

    func setMode(_ mode: AppearanceMode) {
        self.mode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: defaultsKey)
    }
}
