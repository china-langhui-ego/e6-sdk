import SwiftUI

/// 根视图：解析主题（preferredColorScheme + appTheme 注入），按连接态切换配网/预览。
struct RootView: View {
    @EnvironmentObject private var themeManager: ThemeManager
    @EnvironmentObject private var vm: ConnectionViewModel

    var body: some View {
        // preferredColorScheme 作用于 ColorSchemeReader 自身，故其内部读到的 colorScheme
        // 已是手动覆盖后的值；据此注入 appTheme，保证 native chrome 与令牌一致。
        ColorSchemeReader { scheme in
            NavigationView {
                if vm.isConnected {
                    PreviewPlaceholderScreen()
                } else {
                    ConfigScreen()
                }
            }
            .navigationViewStyle(.stack)
            .environment(\.appTheme, themeManager.theme(for: scheme))
        }
        .preferredColorScheme(themeManager.preferredColorScheme())
    }
}
