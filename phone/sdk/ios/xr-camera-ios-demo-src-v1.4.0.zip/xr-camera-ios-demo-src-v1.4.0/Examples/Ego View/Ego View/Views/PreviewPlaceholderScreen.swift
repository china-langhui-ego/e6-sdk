import SwiftUI
import XRCamera

/// 连接成功后的预览屏：视频区 + 统计 + 摄像头组切换 + 播放/停止 + 截图 + 设备信息 + IMU。
struct PreviewPlaceholderScreen: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    /// 渲染载体（@State 持有同一实例，经 representable 嵌入并传给 startPreview）。
    @State private var preview = XRCameraPreview(frame: .zero)
    /// E2 右目渲染载体（双目分屏；E6 不显示、不传入）。
    @State private var preview1 = XRCameraPreview(frame: .zero)
    /// wrist 组左右腕渲染载体（switchGroup(.wrist) + setWristSurfaces 双路直连腕部设备）。
    @State private var wristL = XRCameraPreview(frame: .zero)
    @State private var wristR = XRCameraPreview(frame: .zero)
    /// 腕部详情 sheet（nil=关闭）。
    @State private var wristDetailSide: WristSidePick?

    /// wrist 组模式：不走主流预览，渲染双腕分屏。
    private var isWristMode: Bool { vm.selectedGroup == .wrist }

    /// 是否显示手柄卡片（get_device_info d303d 位域 / get_handshank_status 判定）。
    private var showHandshankCard: Bool { vm.deviceInfo.wristSupported == true }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                StatusBarCard()
                ImuCard()
                videoCard
                // 控制卡：顶部为摄像头组切换 + 开始/停止预览。
                controlsCard
                // 手柄/腕部相机（E6 + ES202；wristSupported 时显示）。
                if showHandshankCard {
                    HandshankCard()
                }
                // E6 专属：手势/投影/USB 开关（E2 不支持），置于控制卡下方。
                if !vm.isE2 {
                    DeviceTogglesCard()
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 6)
        }
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("Ego View")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 14) {
                    NavigationLink(destination: MoreOptionsPage()) {
                        Image(systemName: "ellipsis")
                            .foregroundStyle(theme.text)
                    }
                    Button("断开") { vm.disconnect() }
                        .foregroundStyle(theme.text)
                }
            }
        }
        .background(alertAnchor)
        .onChange(of: vm.vrIp) { ip in
            // IP 到达后不再自动开始预览，由用户手动控制
        }
        .onDisappear {
            // 只在断开连接时停止预览，避免与全屏视图的预览产生竞态条件
            // 全屏视图和竖屏视图共享同一个预览实例，应该保持连续性
            if !vm.isConnected {
                vm.stopPreview()
            }
            // 离开预览页时释放腕部渲染目标（wrist 组内则断双腕）
            vm.setWristSurfaces(left: nil, right: nil)
        }
        .onAppear {
            // 移除自动预览逻辑，完全由用户手动控制；
            // wrist 组恢复（如从全屏返回）时重投渲染目标
            if isWristMode {
                vm.setWristSurfaces(left: wristL, right: wristR)
            }
        }
        .onChange(of: isWristMode) { wrist in
            // 进入 wrist：投递双腕渲染目标（SDK 在 switch_group ok 后按与门补连）；
            // 离开：置 nil 断双腕。
            vm.setWristSurfaces(left: wrist ? wristL : nil, right: wrist ? wristR : nil)
        }
    }

    // MARK: - 录制 / 错误弹窗挂载

    /// 录制成功对话框（sheet，10s 倒计时自动关闭）。
    @State private var showRecordingSuccess = false

    private var alertAnchor: some View {
        Color.clear
            .frame(height: 0)
            .sheet(isPresented: $showRecordingSuccess, onDismiss: { vm.recordingCompletedPath = nil }) {
                ZStack {
                    theme.background.ignoresSafeArea()
                    RecordingSuccessDialog(savePath: vm.recordingCompletedPath ?? "")
                        .padding(24)
                }
            }
            .alert("提示", isPresented: recordingErrorPresented) {
                Button("取消", role: .cancel) { vm.recordingError = nil }
                Button("重试") {
                    vm.recordingError = nil
                    vm.startRecording()
                }
            } message: {
                Text(vm.recordingError.map(recordingErrorMessage) ?? "")
            }
            .alert("提示", isPresented: lastErrorPresented) {
                Button("确定", role: .cancel) { vm.lastError = nil }
            } message: {
                Text(vm.lastError ?? "")
            }
            .onChange(of: vm.recordingCompletedPath) { path in
                if path != nil { showRecordingSuccess = true }
            }
            .sheet(item: $wristDetailSide) { pick in
                WristDetailSheet(side: pick.side)
                        .environmentObject(vm)
            }
    }

    private var recordingErrorPresented: Binding<Bool> {
        Binding(get: { vm.recordingError != nil }, set: { if !$0 { vm.recordingError = nil } })
    }

    /// 连接/预览等失败提示（对应配置页的错误 alert，预览页此前缺失）。
    private var lastErrorPresented: Binding<Bool> {
        Binding(get: { vm.lastError != nil }, set: { if !$0 { vm.lastError = nil } })
    }

    // MARK: - 视频区

    /// 视频区内容：wrist 组双腕分屏（点按弹详情）；E2（SSC）双目分屏（左 L / 右 R）；其余单画面。
    @ViewBuilder
    private var videoContent: some View {
        if isWristMode {
            HStack(spacing: 2) {
                wristPane(preview: wristL, side: .left, label: "L")
                wristPane(preview: wristR, side: .right, label: "R")
            }
        } else if vm.isE2 {
            HStack(spacing: 2) {
                eyePreview(preview, label: "L")
                eyePreview(preview1, label: "R")
            }
        } else {
            VideoPreviewRep(preview: preview)
        }
    }

    /// 单侧腕部画面 + 播放态占位（connecting 显 loading / failed·idle 显占位文案），
    /// 点按进入腕部详情。
    private func wristPane(preview: XRCameraPreview, side: HandshankSide, label: String) -> some View {
        let state = side == .left ? vm.wristPlayback.left : vm.wristPlayback.right
        let playing = state == .playing
        return VideoPreviewRep(preview: preview)
            .overlay(alignment: .topLeading) {
                Text(label)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 5).padding(.vertical, 2)
                    .background(.black.opacity(0.45), in: RoundedRectangle(cornerRadius: 4))
                    .padding(4)
            }
            .overlay {
                if !playing {
                    VStack(spacing: 6) {
                        switch state {
                        case .connecting:
                            ProgressView().tint(.white)
                            Text("连接中…").font(.system(size: 11))
                        case .failed:
                            Image(systemName: "exclamationmark.triangle").font(.system(size: 22))
                            Text("连接失败").font(.system(size: 11))
                        default:
                            Image(systemName: "wristwatch").font(.system(size: 22))
                            Text("等待腕部设备").font(.system(size: 11))
                        }
                    }
                    .foregroundStyle(theme.textDim)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { wristDetailSide = WristSidePick(side: side) }
    }

    private func eyePreview(_ preview: XRCameraPreview, label: String) -> some View {
        VideoPreviewRep(preview: preview)
            .overlay(alignment: .topLeading) {
                Text(label)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 5).padding(.vertical, 2)
                    .background(.black.opacity(0.45), in: RoundedRectangle(cornerRadius: 4))
                    .padding(4)
            }
    }

    private var videoCard: some View {
        videoContent
            .frame(maxWidth: .infinity)
            .frame(height: 220)
            .background(theme.card)
            .overlay(alignment: .topTrailing) {
            VStack(alignment: .trailing, spacing: 6) {
                // 统计信息（主流；wrist 组双腕各自独立推流，demo 不统计）
                if vm.isPlaying, !isWristMode {
                    Text("\(vm.videoStats.width)×\(vm.videoStats.height) | \(vm.videoStats.fps) FPS | \(Int(vm.videoStats.byteRateKBps)) KB/s")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .background(.black.opacity(0.45), in: RoundedRectangle(cornerRadius: 4))
                }

                // 全屏预览已隐藏（返回竖屏时存在状态问题，待修复后再恢复入口）
            }
            .padding(6)
        }
            .overlay {
                // wrist 组占位在各 pane 内展示；主流模式统一占位
                if !vm.isPlaying, !isWristMode {
                    VStack(spacing: 6) {
                        Image(systemName: "video.slash")
                            .font(.system(size: 28))
                        Text("点击「播放」开始预览")
                            .font(.system(size: 12))
                    }
                    .foregroundStyle(theme.textDim)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: theme.cornerRadius))
            .overlay(RoundedRectangle(cornerRadius: theme.cornerRadius).stroke(theme.border, lineWidth: 1))
    }

    // MARK: - 控制区

    private var controlsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            // 摄像头组（segmented；E2 双目固定输出，无组可切）。
            // wrist 项仅 wristSupported == true 时渲染：能力位未知或不支持的设备整个隐藏。
            if !vm.isE2 {
                Picker("摄像头组", selection: $vm.selectedGroup) {
                    ForEach(visibleGroups, id: \.self) { group in
                        Text(groupLabel(group)).tag(group)
                    }
                }
                .pickerStyle(.segmented)
            }

            // 播放 / 停止（wrist 组不走主流预览：切入即自动连双腕，无播放按钮）
            if isWristMode {
                Text("wrist 组：双腕自动连接，点画面查看详情")
                    .font(.system(size: 12))
                    .foregroundStyle(theme.textDim)
                    .frame(maxWidth: .infinity, minHeight: 44)
            } else if vm.isPlaying {
                Button { vm.stopPreview() } label: {
                    Label("停止预览", systemImage: "stop.fill")
                }
                .buttonStyle(XRPrimaryButtonStyle(theme: theme))
            } else {
                Button { vm.startPreview(preview, second: vm.isE2 ? preview1 : nil) } label: {
                    Label("开始预览", systemImage: "play.fill")
                }
                .buttonStyle(XRPrimaryButtonStyle(theme: theme))
            }

            // 截图 / 录制 / 刷新设备信息
            HStack(spacing: 10) {
                Button { vm.takeScreenshot() } label: {
                    Label("截图", systemImage: "camera")
                }
                .buttonStyle(XRSecondaryButtonStyle(theme: theme))
                .disabled(isWristMode)   // 截图取主流 GOP；wrist 组无主流会话

                Button {
                    if vm.isRecording || vm.isArmingRecording {
                        vm.stopRecording()
                    } else {
                        vm.startRecording()
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: (vm.isRecording || vm.isArmingRecording) ? "stop.fill" : "circle.fill")
                            .font(.system(size: 14))
                        Text((vm.isRecording || vm.isArmingRecording) ? "停止录制" : "录制")
                    }
                    .font(.system(size: 15))
                    .foregroundStyle(theme.text)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(recordButtonColor, in: RoundedRectangle(cornerRadius: theme.buttonCornerRadius))
                    .overlay(RoundedRectangle(cornerRadius: theme.buttonCornerRadius).stroke(theme.border, lineWidth: 1))
                }
                .disabled(!vm.isConnected)

                Button { Task { try? await vm.client.getDeviceInfo() } } label: {
                    Label("刷新信息", systemImage: "arrow.clockwise")
                }
                .buttonStyle(XRSecondaryButtonStyle(theme: theme))
            }

            // 音量 / 偏移测试（E6 专属；偏移测试仅 PC 时间同步服务可达时可测）。
            if !vm.isE2 {
                HStack(spacing: 10) {
                    Button { vm.increaseVolume() } label: {
                        Label("音量+", systemImage: "speaker.wave.2.fill")
                    }
                    .buttonStyle(XRSecondaryButtonStyle(theme: theme))

                    Button { vm.decreaseVolume() } label: {
                        Label("音量-", systemImage: "speaker.wave.1.fill")
                    }
                    .buttonStyle(XRSecondaryButtonStyle(theme: theme))

                    Button { vm.offsetTest() } label: {
                        Label("偏移测试", systemImage: "stopwatch")
                    }
                    .buttonStyle(XRSecondaryButtonStyle(theme: theme))
                    .disabled(!vm.timeSyncState.serialAvailable)
                    .opacity(vm.timeSyncState.serialAvailable ? 1 : 0.4)
                }

                // 开始/停止时间同步（随时可切换，仅服务不可达时禁用；采集中红色停止）。
                Button {
                    if vm.timeSyncState.status == .collecting {
                        vm.cancelSync()
                    } else {
                        vm.startSync()
                    }
                } label: {
                    let collecting = vm.timeSyncState.status == .collecting
                    Label(collecting ? "停止同步" : "开始同步",
                          systemImage: collecting ? "stop.fill" : "clock.arrow.circlepath")
                        .foregroundStyle(collecting ? .red : theme.text)
                }
                .buttonStyle(XRSecondaryButtonStyle(theme: theme))
                .disabled(!vm.timeSyncState.serialAvailable)
                .opacity(vm.timeSyncState.serialAvailable ? 1 : 0.4)
            }

            // 截图缩略图
            if let img = vm.lastScreenshot {
                HStack(spacing: 8) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 64, height: 36)
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                        .overlay(RoundedRectangle(cornerRadius: 4).stroke(theme.border, lineWidth: 1))
                    Text("最新截图")
                        .font(.system(size: 11))
                        .foregroundStyle(theme.textDim)
                    Spacer()
                }
            }

            // 录制保存路径（录制停止/分片完成回传）
            if let path = vm.recordingPath {
                Text("录制路径：\(path)")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(theme.textDim)
                    .lineLimit(2)
            }
        }
        .xrCard(theme)
        .onChange(of: vm.selectedGroup) { group in vm.switchGroup(group) }
    }

    /// 录制按钮底色：录制中红 / 准备中琥珀 / 常态 accent。
    private var recordButtonColor: Color {
        if vm.isRecording { return .red }
        if vm.isArmingRecording { return theme.warning }
        return theme.accent
    }

    /// 组菜单可见项：wrist 仅能力位确认 true 时出现。
    private var visibleGroups: [CameraGroup] {
        CameraGroup.allCases.filter { $0 != .wrist || vm.deviceInfo.wristSupported == true }
    }

    private func groupLabel(_ group: CameraGroup) -> String {
        switch group {
        case .tracking: "TRACK"
        case .rgb: "RGB"
        case .ctrl: "CTRL"
        case .wrist: "WRIST"
        }
    }
}

// MARK: - XRCameraPreview 的 SwiftUI 包装

private struct VideoPreviewRep: UIViewRepresentable {
    let preview: XRCameraPreview

    func makeUIView(context: Context) -> XRCameraPreview { preview }
    func updateUIView(_ uiView: XRCameraPreview, context: Context) {}
}
