import SwiftUI

/// 状态点：连接中呼吸动画，稳态（绿/灰/红）完全静止。
///
/// 呼吸动画放在独立子视图 `PulsingDot` 中，且该子视图**仅在连接中存在**——
/// 非连接态走无任何动画修饰符的静态分支，从结构上杜绝 repeatForever
/// 动画残留（对 `.animation(nil)` / `.default` 打断不可靠的兜底）。
struct StatusDot: View {
    let color: Color
    var isConnecting: Bool = false

    var body: some View {
        if isConnecting {
            PulsingDot(color: color)
        } else {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
        }
    }
}

/// 呼吸圆点（仅连接中渲染；出现即开始脉冲，随视图移除而停止）。
private struct PulsingDot: View {
    let color: Color
    @State private var pulse = false

    var body: some View {
        Circle()
            .fill(color)
            .frame(width: 8, height: 8)
            .scaleEffect(pulse ? 1.3 : 1.0)
            .opacity(pulse ? 0.5 : 1.0)
            .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: pulse)
            .onAppear { pulse = true }
    }
}
