import SwiftUI
import XRCamera

/// 状态栏 + WiFi 配置 + 扫描，顶栏主题切换，进入自动扫描。
struct ConfigScreen: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @EnvironmentObject private var themeManager: ThemeManager
    @Environment(\.appTheme) private var theme

    var body: some View {
        ScrollView {
            VStack(spacing: 6) {
                StatusBarCard()
                WifiConfigCard()
                DeviceScanCard()
            }
            .padding(.horizontal, 16)
            .padding(.top, 6)
            .padding(.bottom, 16)
        }
        .background(theme.background.ignoresSafeArea())
        .navigationTitle("Ego View")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    ForEach(AppearanceMode.allCases) { mode in
                        Button {
                            themeManager.setMode(mode)
                        } label: {
                            if themeManager.mode == mode {
                                Label(mode.label, systemImage: "checkmark")
                            } else {
                                Text(mode.label)
                            }
                        }
                    }
                } label: {
                    Label("主题", systemImage: "paintpalette")
                }
            }
        }
        .onAppear {
            vm.startObservingEvents()
            vm.scan()
        }
        .alert("提示",
               isPresented: Binding(get: { vm.lastError != nil },
                                    set: { _ in vm.lastError = nil })) {
            Button("好", role: .cancel) {}
        } message: {
            Text(vm.lastError ?? "")
        }
    }
}
