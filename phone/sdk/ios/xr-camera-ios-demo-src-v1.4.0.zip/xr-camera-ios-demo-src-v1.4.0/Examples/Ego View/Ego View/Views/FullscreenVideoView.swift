import SwiftUI
import XRCamera

/// 全屏横屏视频预览视图
///
/// **Preview 实例共享：**
/// - preview 实例从 PreviewPlaceholderScreen 传递，保持引用不变
/// - 视频播放不中断，无需重新调用 startPreview
/// - 两个视图共享同一个 XRCameraPreview 底层 UIView
///
/// **生命周期：**
/// 1. onAppear: 强制横屏 + 启动自动隐藏定时器
/// 2. onDisappear: 恢复竖屏 + 取消定时器
/// 3. dismiss: NavigationLink 自动返回上一视图
///
/// **功能：**
/// - 共享 XRCameraPreview 实例实现无缝切换
/// - 悬浮控制栏提供播放控制和镜头选择
/// - 5秒自动隐藏控制栏，点击屏幕重新显示
/// - 强制横屏方向，退出时恢复竖屏
struct FullscreenVideoView: View {
    /// 共享的视频预览实例（从 PreviewPlaceholderScreen 传递）
    let preview: XRCameraPreview
    /// 共享的 E2 右目预览实例（全屏仅显示左目，但重启预览时需保持双目解码不断流）
    var second: XRCameraPreview? = nil

    /// 连接视图模型（EnvironmentObject 注入）
    @EnvironmentObject private var vm: ConnectionViewModel

    /// 应用主题
    @Environment(\.appTheme) private var theme

    /// 控制栏可见性状态
    @State private var isControlBarVisible: Bool = true

    /// 自动隐藏定时器
    @State private var hideTimer: Task<Void, Never>?

    /// 横屏错误提示
    @State private var orientationError: String?

    /// 退出全屏的 dismiss 环境
    @Environment(\.dismiss) private var dismiss

    /// 重置自动隐藏定时器
    ///
    /// **性能考虑：**
    /// - 使用 Task.sleep 而非 DispatchQueue，避免 RunLoop 竞争
    /// - 定时器持有为 @State，确保视图生命周期内正确管理
    /// - onDisappear 取消定时器，避免后台内存泄漏
    private func resetHideTimer() {
        // 取消现有的定时器
        hideTimer?.cancel()

        // 创建新的5秒倒计时
        hideTimer = Task {
            do {
                try await Task.sleep(nanoseconds: 5_000_000_000) // 5秒

                // 检查任务是否被取消（用户可能重新点击）
                if !Task.isCancelled {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isControlBarVisible = false
                    }
                }
            } catch {
                // 任务被取消，静默忽略
            }
        }
    }

    var body: some View {
        ZStack {
            // 视频预览层
            videoPreviewLayer
                .contentShape(Rectangle()) // 只在视频层应用点击手势
                .onTapGesture {
                    // 仅在控制栏隐藏时响应点击
                    guard !isControlBarVisible else { return }

                    withAnimation(.easeInOut(duration: 0.3)) {
                        isControlBarVisible = true
                    }
                    resetHideTimer()
                }

            // 统计信息 overlay (右上角)
            if vm.isPlaying {
                statsOverlay
            }

            // 预览停止提示 overlay
            if !vm.isPlaying {
                previewStoppedOverlay
            }

            // 错误提示 overlay
            if let error = orientationError {
                Text(error)
                    .font(.system(size: 12))
                    .foregroundStyle(.white)
                    .padding()
                    .background(.red.opacity(0.8), in: RoundedRectangle(cornerRadius: 8))
                    .padding()
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            // 控制栏 overlay (底部)
            if isControlBarVisible {
                VStack {
                    Spacer()
                    controlBar
                }
            }
        }
        .background(.black)
        .ignoresSafeArea()
        .navigationTitle("全屏预览")
        .navigationBarHidden(true)
        .onChange(of: orientationError) { error in
            if error != nil {
                // 3秒后自动清除错误提示
                Task {
                    try? await Task.sleep(nanoseconds: 3_000_000_000)
                    if !Task.isCancelled {
                        orientationError = nil
                    }
                }
            }
        }
        .onAppear {
            forceLandscapeOrientation()
            resetHideTimer() // 启动自动隐藏定时器

            // 移除自动预览逻辑，避免与 onDisappear 的 stopPreview() 产生竞态条件
            // 保持与竖屏一致的手动控制：用户通过播放/停止按钮控制预览
        }
        .onDisappear {
            restorePortraitOrientation()
            hideTimer?.cancel() // 清理定时器，避免内存泄漏

            // 退出全屏时不停止预览，让PreviewPlaceholderScreen继续显示
            // 这样可以实现无缝的全屏/竖屏切换
        }
    }

    // MARK: - Computed Properties

    /// 视频预览层 - 使用共享的 XRCameraPreview 实例
    private var videoPreviewLayer: some View {
        VideoPreviewRep(preview: preview)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    /// 统计信息 overlay - 显示在右上角
    private var statsOverlay: some View {
        Text("\(vm.videoStats.width)×\(vm.videoStats.height)  \(vm.videoStats.fps)fps  \(Int(vm.videoStats.byteRateKBps))KB/s")
            .font(.system(size: 12, weight: .medium, design: .monospaced))
            .foregroundStyle(.white)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(.black.opacity(0.5), in: RoundedRectangle(cornerRadius: 6))
            .padding(12)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
    }

    /// 预览停止提示 overlay
    private var previewStoppedOverlay: some View {
        VStack(spacing: 12) {
            Image(systemName: "video.slash")
                .font(.system(size: 48))
                .foregroundStyle(.white.opacity(0.8))

            Text("预览已停止")
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(.white)

            Button("重新开始预览") {
                vm.startPreview(preview, second: second)
                resetHideTimer() // 重置定时器
            }
            .buttonStyle(.borderedProminent)
            .tint(theme.accent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.black.opacity(0.7))
    }

    /// 控制栏 - 底部悬浮，包含播放控制、镜头选择、退出全屏
    @ViewBuilder
    private var controlBar: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                // 左侧：停止/开始按钮
                playStopButton

                // 中间：镜头选择分段控制器
                Spacer()
                cameraGroupPicker
                Spacer()

                // 右侧：退出全屏按钮
                exitFullscreenButton
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 18)
            .background(.black.opacity(0.65), in: RoundedCorner(cornerRadius: 20, corners: [.topLeft, .topRight]))

            // 底部安全区域填充
            Color.black.opacity(0.65)
                .frame(height: 0) // 使用 safeAreaPadding 自动处理
        }
        .padding(.bottom, 0)
    }

    /// 停止/开始预览按钮
    private var playStopButton: some View {
        Button {
            // 重置定时器，避免操作后立即隐藏
            resetHideTimer()

            if vm.isPlaying {
                vm.stopPreview()
            } else {
                vm.startPreview(preview, second: second)
            }
        } label: {
            Label(vm.isPlaying ? "停止" : "开始", systemImage: vm.isPlaying ? "stop.fill" : "play.fill")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 100, height: 44)
                .background(theme.accent, in: RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
        // wrist 组不走主流预览（start_preview 无效），全屏下禁用播放
        .disabled(vm.selectedGroup == .wrist)
        .opacity(vm.selectedGroup == .wrist ? 0.4 : 1)
        .contentShape(Rectangle()) // 确保整个按钮区域可点击
    }

    /// 镜头选择分段控制器（增强可见性）
    private var cameraGroupPicker: some View {
        Picker("摄像头组", selection: $vm.selectedGroup) {
            // wrist 仅能力位确认 true 时出现。
            ForEach(CameraGroup.allCases.filter { $0 != .wrist || vm.deviceInfo.wristSupported == true },
                    id: \.self) { group in
                Text(groupLabel(group)).tag(group)
            }
        }
        .pickerStyle(.segmented)
        .frame(width: 200)
        .background(
            // 增强背景：在浅色主题下添加半透明白色背景
            RoundedRectangle(cornerRadius: 8)
                .fill(.white.opacity(0.15))
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(.white.opacity(0.3), lineWidth: 1)
                )
        )
        .onChange(of: vm.selectedGroup) { group in
            vm.switchGroup(group)
        }
    }

    /// 镜头组标签转换
    private func groupLabel(_ group: CameraGroup) -> String {
        switch group {
        case .tracking: return "TRACK"
        case .rgb: return "RGB"
        case .ctrl: return "CTRL"
        case .wrist: return "WRIST"
        }
    }

    /// 退出全屏按钮
    private var exitFullscreenButton: some View {
        Button {
            dismiss()
        } label: {
            Image(systemName: "arrow.down.right.and.arrow.up.left")
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .background(.black.opacity(0.5), in: Circle())
        }
        .buttonStyle(.plain)
        .contentShape(Rectangle()) // 确保整个按钮区域可点击
    }

    // MARK: - Screen Orientation

    /// 强制切换到横屏方向
    private func forceLandscapeOrientation() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else {
            orientationError = "无法获取窗口场景"
            return
        }

        if #available(iOS 16.0, *) {
            windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .landscapeLeft)) { error in
                orientationError = "横屏切换 error: \(error.localizedDescription)"
            }
        } else {
            UIDevice.current.setValue(UIInterfaceOrientation.landscapeLeft.rawValue, forKey: "orientation")
            UIViewController.attemptRotationToDeviceOrientation()
        }
    }

    /// 恢复竖屏方向
    private func restorePortraitOrientation() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else {
            return
        }

        if #available(iOS 16.0, *) {
            windowScene.requestGeometryUpdate(.iOS(interfaceOrientations: .portrait)) { error in
                print("恢复竖屏 error: \(error.localizedDescription)")
            }
        } else {
            UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
            UIViewController.attemptRotationToDeviceOrientation()
        }
    }
}

// MARK: - UIViewRepresentable Wrapper

/// VideoPreviewRep - UIViewRepresentable wrapper for XRCameraPreview
private struct VideoPreviewRep: UIViewRepresentable {
    let preview: XRCameraPreview

    func makeUIView(context: Context) -> XRCameraPreview { preview }
    func updateUIView(_ uiView: XRCameraPreview, context: Context) {}
}

// MARK: - Custom Shapes

struct RoundedCorner: Shape {
    var cornerRadius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: cornerRadius, height: cornerRadius)
        )
        return Path(path.cgPath)
    }
}
