import SwiftUI
import XRCamera

/// `DeviceScanCard`：扫描按钮 + 设备列表。
struct DeviceScanCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                vm.scan()
            } label: {
                if vm.isScanning {
                    ProgressView().tint(theme.text).frame(maxWidth: .infinity, minHeight: 44)
                } else {
                    Text("扫描设备").frame(maxWidth: .infinity, minHeight: 44)
                }
            }
            .buttonStyle(XRSecondaryButtonStyle(theme: theme))
            .disabled(vm.isScanning || vm.isConnected)

            if !vm.scannedDevices.isEmpty {
                VStack(spacing: 4) {
                    ForEach(vm.scannedDevices) { device in
                        DeviceRow(device: device)
                    }
                }
            }
        }
        .xrCard(theme, padding: 20)
    }
}

private struct DeviceRow: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme
    let device: XrDevice

    private var enabled: Bool {
        !vm.ssid.trimmingCharacters(in: .whitespaces).isEmpty
            && !vm.isConnected
            && vm.connectionState != .connecting
    }

    var body: some View {
        Button {
            if vm.ssid.trimmingCharacters(in: .whitespaces).isEmpty {
                vm.lastError = "请输入 WiFi 名称"
            } else {
                vm.connect(device)
            }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .foregroundStyle(theme.textDim.opacity(enabled ? 1 : 0.4))
                Text(displayName)
                    .foregroundStyle(theme.text.opacity(enabled ? 1 : 0.4))
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "chevron.right")
                    .foregroundStyle(theme.textDim.opacity(enabled ? 1 : 0.4))
            }
            .font(.system(size: 14))
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(theme.accent, in: RoundedRectangle(cornerRadius: theme.cornerRadius))
        }
    }

    private var displayName: String {
        device.serialNumber.isEmpty ? device.name : "\(device.name) · \(device.serialNumber)"
    }
}
