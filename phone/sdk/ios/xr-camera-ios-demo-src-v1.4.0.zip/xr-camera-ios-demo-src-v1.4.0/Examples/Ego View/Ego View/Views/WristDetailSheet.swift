import SwiftUI
import XRCamera

/// 腕部详情页（点 wrist 分屏某侧进入）：
/// 进入拉 getWristDetail + 开 IMU 推送（约 1Hz），离开关 IMU。
/// detail 为 nil（未就绪空壳）显示占位；accel/gyro 实时刷新。
struct WristDetailSheet: View {
    let side: HandshankSide
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme
    @Environment(\.dismiss) private var dismiss

    private var detail: WristDetail? { vm.wristDetails[side] }
    private var imu: WristImuData? { vm.wristImu[side] }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 12) {
                    detailCard
                    imuCard
                    Button { vm.getWristDetail(side) } label: {
                        Label("刷新详情", systemImage: "arrow.clockwise")
                    }
                    .buttonStyle(XRSecondaryButtonStyle(theme: theme))
                }
                .padding(16)
            }
            .background(theme.background.ignoresSafeArea())
            .navigationTitle(side == .left ? "左腕详情" : "右腕详情")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }.foregroundStyle(theme.text)
                }
            }
        }
        .navigationViewStyle(.stack)   // iOS 15：sheet 内避免 DoubleColumn 折叠
        .onAppear {
            vm.getWristDetail(side)
            vm.setWristImuEnabled(true)
        }
        .onDisappear {
            vm.setWristImuEnabled(false)
        }
    }

    // MARK: - 详情

    @ViewBuilder
    private var detailCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("设备信息", systemImage: "wristwatch")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(theme.text)
            if let detail {
                infoRow("SN", detail.sn)
                infoRow("版本", detail.version)
                infoRow("WiFi", detail.wifiSsid)
                infoRow("IP", detail.wifiIp)
                if let battery = detail.battery {
                    infoRow("电量", "\(battery)%")
                }
                if let total = detail.storageTotalMb, let used = detail.storageUsedMb {
                    infoRow("存储", "\(used) / \(total) MB（已用 \(Int(Double(used) / Double(max(total, 1)) * 100))%）")
                }
            } else {
                HStack(spacing: 8) {
                    Image(systemName: "wristwatch")
                        .font(.system(size: 22))
                    Text("未就绪（该侧腕部设备未连接或离线）")
                        .font(.system(size: 12))
                }
                .foregroundStyle(theme.textDim)
                .frame(maxWidth: .infinity, minHeight: 60)
            }
        }
        .xrCard(theme)
    }

    private func infoRow(_ title: String, _ value: String?) -> some View {
        HStack(alignment: .top) {
            Text(title)
                .font(.system(size: 13))
                .foregroundStyle(theme.textDim)
            Spacer()
            Text(value ?? "—")
                .font(.system(size: 13, design: .monospaced))
                .foregroundStyle(theme.text)
                .multilineTextAlignment(.trailing)
        }
    }

    // MARK: - IMU（约 1Hz 推送）

    private var imuCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("IMU（实时）", systemImage: "speedometer")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(theme.text)
            if let imu {
                imuRow("Accel (m/s²)", imu.ax, imu.ay, imu.az)
                imuRow("Gyro (°/s)", imu.gx, imu.gy, imu.gz)
            } else {
                Text("等待数据…")
                    .font(.system(size: 12))
                    .foregroundStyle(theme.textDim)
                    .frame(maxWidth: .infinity, minHeight: 40)
            }
        }
        .xrCard(theme)
    }

    private func imuRow(_ title: String, _ x: Double?, _ y: Double?, _ z: Double?) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 12))
                .foregroundStyle(theme.textDim)
            HStack(spacing: 12) {
                axisText("X", x)
                axisText("Y", y)
                axisText("Z", z)
            }
        }
    }

    private func axisText(_ label: String, _ value: Double?) -> some View {
        HStack(spacing: 4) {
            Text(label)
                .font(.system(size: 12, design: .monospaced))
                .foregroundStyle(theme.textDim)
            Text(value.map { String(format: "%.2f", $0) } ?? "—")
                .font(.system(size: 12, design: .monospaced))
                .foregroundStyle(theme.text)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// sheet(item:) 的 Identifiable 包装。
struct WristSidePick: Identifiable {
    let side: HandshankSide
    var id: String { side.rawValue }
}
