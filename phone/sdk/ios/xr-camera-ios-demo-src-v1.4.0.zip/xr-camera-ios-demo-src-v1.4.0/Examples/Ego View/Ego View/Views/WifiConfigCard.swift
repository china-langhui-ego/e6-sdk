import SwiftUI

/// SSID/密码输入 + 保存（持久化）。
struct WifiConfigCard: View {
    @EnvironmentObject private var vm: ConnectionViewModel
    @Environment(\.appTheme) private var theme

    @State private var showPassword = false
    @State private var showSaved = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("WiFi 配置")
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(theme.text)

            TextField("WiFi 名称", text: $vm.ssid)
                .textFieldStyle(XRFieldStyle(theme: theme))
                .frame(height: 35)
            Spacer(minLength: 2)
            HStack(spacing: 6) {
                Group {
                    if showPassword {
                        TextField("WiFi 密码", text: $vm.password)
                    } else {
                        SecureField("WiFi 密码", text: $vm.password)
                    }
                }
                .textFieldStyle(XRFieldStyle(theme: theme))
                .frame(height: 35)

                Button { showPassword.toggle() } label: {
                    Image(systemName: showPassword ? "eye.slash" : "eye")
                        .foregroundStyle(theme.textDim)
                }
            }

            Button {
                if vm.ssid.trimmingCharacters(in: .whitespaces).isEmpty {
                    vm.lastError = "请输入 WiFi 名称"
                } else {
                    vm.saveWifiConfig()
                    showSaved = true
                }
            } label: {
                Text("保存配置")
            }
            .buttonStyle(XRPrimaryButtonStyle(theme: theme))
        }
        .xrCard(theme)
        .alert("已保存", isPresented: $showSaved) { Button("好", role: .cancel) {} }
    }
}
