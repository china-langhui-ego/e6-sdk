import SwiftUI

/// 录制成功对话框：
/// ✓ 图标 + 标题 + VR 保存路径（等宽字体），10 秒倒计时自动关闭。
struct RecordingSuccessDialog: View {
    @Environment(\.appTheme) private var theme
    @Environment(\.dismiss) private var dismiss

    let savePath: String
    @State private var countdown = 10
    @State private var timer: Timer?

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 28))
                    .foregroundStyle(theme.success)
                Text("录制成功")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(theme.text)
            }
            .padding(.bottom, 14)

            Text("数据存储路径（VR）：")
                .font(.system(size: 14))
                .foregroundStyle(theme.textDim)
            Text(savePath)
                .font(.system(size: 14, design: .monospaced))
                .foregroundStyle(theme.text)
                .lineLimit(3)
                .padding(.top, 8)

            Button {
                close()
            } label: {
                Text("关闭（\(countdown)s）")
                    .font(.system(size: 14))
                    .foregroundStyle(theme.text)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(theme.accent, in: RoundedRectangle(cornerRadius: 8))
            }
            .padding(.top, 18)
        }
        .padding(20)
        .background(theme.card)
        .clipShape(RoundedRectangle(cornerRadius: theme.cornerRadius))
        .onAppear { startCountdown() }
        .onDisappear { timer?.invalidate() }
    }

    private func startCountdown() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { t in
            if countdown > 1 {
                countdown -= 1
            } else {
                t.invalidate()
                close()
            }
        }
    }

    private func close() {
        timer?.invalidate()
        dismiss()
    }
}

/// 录制错误文案映射。
func recordingErrorMessage(_ error: String) -> String {
    switch error {
    case "sd_card_not_detected": return "未检测到 SD 卡"
    case "sd_card_error": return "SD 卡异常，请检查后再试"
    case "storage_full": return "SD 卡存储空间已满，录制结束"
    default: return "录制异常: \(error)"
    }
}
