import SwiftUI

/// 卡片容器： `bgCard` + `colorBorder` + 12 圆角。
extension View {
    func xrCard(_ theme: AppTheme, padding: CGFloat = 12) -> some View {
        self
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(theme.card)
            .overlay(RoundedRectangle(cornerRadius: theme.cornerRadius).stroke(theme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: theme.cornerRadius))
    }
}

/// 输入框：accent 填充 + 8 圆角。
struct XRFieldStyle: TextFieldStyle {
    let theme: AppTheme
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .foregroundStyle(theme.text)
            .background(theme.accent, in: RoundedRectangle(cornerRadius: 8))
    }
}

/// 主按钮：highlight 底 + 白字 + 按下透明度。
struct XRPrimaryButtonStyle: ButtonStyle {
    let theme: AppTheme
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 44)
            .background(theme.highlight, in: RoundedRectangle(cornerRadius: theme.buttonCornerRadius))
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

/// 次级按钮：accent 底 + 主文本。
struct XRSecondaryButtonStyle: ButtonStyle {
    let theme: AppTheme
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15))
            .foregroundStyle(theme.text)
            .frame(maxWidth: .infinity, minHeight: 44)
            .background(theme.accent, in: RoundedRectangle(cornerRadius: theme.buttonCornerRadius))
            .overlay(RoundedRectangle(cornerRadius: theme.buttonCornerRadius).stroke(theme.border, lineWidth: 1))
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}
