// swift-tools-version:5.9
// 闭源发布壳：demo 经本地 XRCamera.xcframework 集成（由 archive_release_xcframework_demo.sh 生成）。
import PackageDescription

let package = Package(
    name: "XRCamera",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "XRCamera", targets: ["XRCamera"])
    ],
    targets: [
        .binaryTarget(name: "XRCamera", path: "XRCamera.xcframework")
    ]
)
